@extends("templates.basic")

@section("title")
Log In
@endsection

@section("content")

<style>
.form-region {
  border: 1px solid #cccccc;
  padding: 2em;
  border-radius: 20px;
  box-shadow: 0 0 5px #cccccc;
}
</style>

<div class="container-fluid">
  <div class="row">
    <div class="col-xs-3"></div>
    <div class="col-xs-6 text-center">
      <img src="/img/xlogo.png" style="width:10em;margin-top:80px">
    </div>
  </div>
  <div class="row">
    <div class="col-xs-3"></div>
    <div class="col-xs-6 text-center"
      style="font-weight:bold;font-size:2em;margin-top:1em;margin-bottom:1em">
      Log In
    </div>
  </div>
  <div class="row">
    <div class="col-xs-3"></div>
    <form action="/auth/login" method="post" class="form-horizontal col-xs-6 form-region">
      <div class="form-group">
        <div class="col-xs-12">
          @if (count($errors) > 0)
            <div class="alert alert-danger">
              <ul>
                @foreach ($errors->all() as $error)
                  <li>{{$error}}</li>
                @endforeach
              </ul>
            </div>
          @endif
          {{csrf_field()}}
        </div>
      </div>
      <div class="form-group">
        <div class="col-xs-12">
          <div class="input-group">
            <span class="input-group-addon">@</span>
            <input class="form-control" type="text" name="email"
              placeholder="Email">
          </div>
        </div>
      </div>
      <div class="form-group">
        <div class="col-xs-12">
          <div class="input-group">
            <span class="input-group-addon">
              <span class="glyphicon glyphicon-asterisk"></span>
            </span>
            <input class="form-control" type="password" name="password"
              placeholder="Password">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-xs-12">
          <input class="btn btn-primary" style="width:100%" type="submit">
        </div>
      </div>
    </form>
  </div>
</div>

@endsection
