New student registration:
<br />
@foreach($data as $key => $value)
    {{$key}} : {{$value}}
    <br />
@endforeach