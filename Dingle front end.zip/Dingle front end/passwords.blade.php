@extends("templates.dashboard")

@section("content")
<div class="container-fluid">
    <h1>Change Password For {{$user->name}}</h1>
    <form method="post" class="col-md-6">
        <div class="form-group">
            <label for="password">Password</label>
            <input type="text" id="password" name="password" class="form-control">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-default">Change Password</button>
        </div>
    </form>
</div>
@endsection