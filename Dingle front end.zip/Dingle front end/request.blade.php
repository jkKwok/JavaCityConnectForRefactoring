<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta content="IE=edge" http-equiv="X-UA-Compatible">
    <meta content="{{ csrf_token() }}" name="csrf-token">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <meta content="" name="description">
    <meta content="" name="author">
    <title>DingleX</title><!-- Bootstrap Core CSS -->
    <link href="/css/bootstrap.min.css" rel="stylesheet"><!-- Custom CSS -->
    <link href="/css/assignment.css" rel="stylesheet">
    <link href="/css/agency.css" rel="stylesheet"><!-- Custom Fonts -->
    <link href="/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>
    <link href="img/favicon.ico" rel="icon" type="image/png"><!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- jQuery -->

    <script src="/js/jquery.js">
    </script>
    <script src="/js/dingle.js">
    </script><!-- Bootstrap Core JavaScript -->

    <script src="/js/bootstrap.min.js">
    </script><!-- Plugin JavaScript -->

    <script src="/js/jquery.easing.min.js">
    </script>
    <script src="/js/classie.js">
    </script>
    <script src="/js/cbpAnimatedHeader.js">
    </script><!-- Contact Form JavaScript -->

    <script src="/js/jqBootstrapValidation.js">
    </script><!--     <script src="js/contact_me.js"></script> -->
    <!-- Custom Theme JavaScript -->

    <script src="/js/agency.js">
    </script>
</head>
<body class="index" id="page-top">
    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button class="navbar-toggle" data-target="#bs-example-navbar-collapse-1" data-toggle="collapse" type="button"><span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span></button> <a class="navbar-brand page-scroll" href="index.php">DingleX</a>
            </div><!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="index.php">Service Details</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="index.php">About</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="index.php">Contact</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="signup">Sign up as a Tutor</a>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav><!-- Header -->
    <header>
        @if(isset($success))
        <script>
          alert("Your request has been submitted! We'll be in contact shortly.");
          location.href = '/';
        </script> @endif
        <div class="container">
            <div class="intro-text">
                <div class="intro-lead-in">
                    Let us solve your academic problems
                </div>
                <div class="intro-heading">
                    Fill in the form below
                </div>
            </div>
        </div>
    </header>
    <div class="col-md-3">
        <h3><strong>Getting started</strong></h3>
        <p>&nbsp;</p>
        <p>Dear parents and students, kindly fill in the request form on the left to request for a tutor. One of our friendly staff will attend to you within 12 hours.</p>
        <p><strong>You get to enjoy the following:</strong></p>
        <p>1. Free matching service<br>
        2. No hidden charges<br>
        3. Commission is levied from tutor</p>
        <p><strong>Request a tutor via phone</strong></p>
        <p>We accept phone request too. Call us at <span style="color: #f2664f;"><strong>97881548 (SMS)</strong></span>. We will be more than happy to help you.</p>
    </div>
    <div class="col-md-9" id="home-tutor-table">
        <form action="/request" id="frmTutor" method="post" name="frmTutor">
            <h3>Student (Tutee) Particulars</h3>
            <p>For <b>group tuition</b> (more than 1 student), fill in details of one of them below and indicate the number of students and other details in the "5. Remarks, Notes &amp; Other Requirements" section.</p>
            <div class="form-group">
                <label>Name</label> <input class="form-control" maxlength="20" name="name" size="20" type="text" required>
            </div>
            <div class="form-group">
                <label>Year of Birth</label> <!-- ~~~~~ ~~~~~ | Year | ~~~~~ ~~~~~ -->
                 <select class="form-control" name="birth_year">
                    <option value="">
                        - Select One -
                    </option>
                    <option value="2011">
                        2011
                    </option>
                    <option value="2010">
                        2010
                    </option>
                    <option value="2009">
                        2009
                    </option>
                    <option value="2008">
                        2008
                    </option>
                    <option value="2007">
                        2007
                    </option>
                    <option value="2006">
                        2006
                    </option>
                    <option value="2005">
                        2005
                    </option>
                    <option value="2004">
                        2004
                    </option>
                    <option value="2003">
                        2003
                    </option>
                    <option value="2002">
                        2002
                    </option>
                    <option value="2001">
                        2001
                    </option>
                    <option value="2000">
                        2000
                    </option>
                    <option value="1999">
                        1999
                    </option>
                    <option value="1998">
                        1998
                    </option>
                    <option value="1997">
                        1997
                    </option>
                    <option value="1996">
                        1996
                    </option>
                    <option value="1995">
                        1995
                    </option>
                    <option value="1994">
                        1994
                    </option>
                    <option value="1993">
                        1993
                    </option>
                    <option value="1992">
                        1992
                    </option>
                    <option value="1991">
                        1991
                    </option>
                    <option value="1990">
                        1990
                    </option>
                    <option value="1989">
                        1989
                    </option>
                    <option value="1988">
                        1988
                    </option>
                    <option value="1987">
                        1987
                    </option>
                    <option value="1986">
                        1986
                    </option>
                    <option value="1985">
                        1985
                    </option>
                    <option value="1984">
                        1984
                    </option>
                    <option value="1983">
                        1983
                    </option>
                    <option value="1982">
                        1982
                    </option>
                    <option value="1981">
                        1981
                    </option>
                    <option value="1980">
                        1980
                    </option>
                    <option value="1979">
                        1979
                    </option>
                    <option value="1978">
                        1978
                    </option>
                    <option value="1977">
                        1977
                    </option>
                    <option value="1976">
                        1976
                    </option>
                    <option value="1975">
                        1975
                    </option>
                    <option value="1974">
                        1974
                    </option>
                    <option value="1973">
                        1973
                    </option>
                    <option value="1972">
                        1972
                    </option>
                    <option value="1971">
                        1971
                    </option>
                    <option value="1970">
                        1970
                    </option>
                    <option value="1969">
                        1969
                    </option>
                    <option value="1968">
                        1968
                    </option>
                    <option value="1967">
                        1967
                    </option>
                    <option value="1966">
                        1966
                    </option>
                    <option value="1965">
                        1965
                    </option>
                    <option value="1964">
                        1964
                    </option>
                    <option value="1963">
                        1963
                    </option>
                    <option value="1962">
                        1962
                    </option>
                    <option value="1961">
                        1961
                    </option>
                    <option value="1960">
                        1960
                    </option>
                    <option value="1959">
                        1959
                    </option>
                    <option value="1958">
                        1958
                    </option>
                    <option value="1957">
                        1957
                    </option>
                    <option value="1956">
                        1956
                    </option>
                    <option value="1955">
                        1955
                    </option>
                    <option value="1954">
                        1954
                    </option>
                    <option value="1953">
                        1953
                    </option>
                    <option value="1952">
                        1952
                    </option>
                    <option value="1951">
                        1951
                    </option>
                    <option value="1950">
                        1950
                    </option>
                    <option value="1949">
                        1949
                    </option>
                    <option value="1948">
                        1948
                    </option>
                    <option value="1947">
                        1947
                    </option>
                    <option value="1946">
                        1946
                    </option>
                    <option value="1945">
                        1945
                    </option>
                    <option value="1944">
                        1944
                    </option>
                    <option value="1943">
                        1943
                    </option>
                    <option value="1942">
                        1942
                    </option>
                    <option value="1941">
                        1941
                    </option>
                    <option value="1940">
                        1940
                    </option>
                    <option value="1939">
                        1939
                    </option>
                    <option value="1938">
                        1938
                    </option>
                    <option value="1937">
                        1937
                    </option>
                    <option value="1936">
                        1936
                    </option>
                    <option value="1935">
                        1935
                    </option>
                    <option value="1934">
                        1934
                    </option>
                    <option value="1933">
                        1933
                    </option>
                    <option value="1932">
                        1932
                    </option>
                    <option value="1931">
                        1931
                    </option>
                    <option value="1930">
                        1930
                    </option>
                    <option value="1929">
                        1929
                    </option>
                    <option value="1928">
                        1928
                    </option>
                    <option value="1927">
                        1927
                    </option>
                    <option value="1926">
                        1926
                    </option>
                    <option value="1925">
                        1925
                    </option>
                    <option value="1924">
                        1924
                    </option>
                    <option value="1923">
                        1923
                    </option>
                    <option value="1922">
                        1922
                    </option>
                    <option value="1921">
                        1921
                    </option>
                    <option value="1920">
                        1920
                    </option>
                </select>
            </div>
            <div class="form-group">
                <label>Gender</label> <select class="form-control" name="gender">
                    <option value="">
                        - Select One -
                    </option>
                    <option value="male">
                        Male
                    </option>
                    <option value="female">
                        Female
                    </option>
                </select>
            </div>
            <div class="form-group">
                <label>Nationality</label> <select aria-expanded="false" class="form-control others" data-target="#nationality_others" name="nationality">
                    <option value="">
                        - Select One -
                    </option>
                    <option value="SG">
                        Singaporean
                    </option>
                    <option value="MY">
                        Malaysian
                    </option>
                    <option value="EU">
                        Eurasian
                    </option>
                    <option value="others">
                        Others
                    </option>
                </select> <span class="form-control collapse fade" id="nationality_others"><input class="form-control" maxlength="20" name="nationality_others" size="20" type="text"> <i>(Please specify)</i></span>
            </div>
            <div class="form-group">
                <label>Race</label> <select aria-expanded="false" class="form-control others" data-target="#race_others" name="race">
                    <option value="">
                        - Select One -
                    </option>
                    <option value="chinese">
                        Chinese
                    </option>
                    <option value="malay">
                        Malay
                    </option>
                    <option value="indian">
                        Indian
                    </option>
                    <option value="eurasian">
                        Eurasian
                    </option>
                    <option value="others">
                        Others
                    </option>
                </select> <span class="collapse fade" id="race_others"><input class="form-control" maxlength="20" name="race_others" size="20" type="text"> <i>(Please specify)</i></span>
            </div>
            <div class="form-group">
                <label>Tutoring Location</label> <input class="form-control" maxlength="50" name="location" size="40" type="text"> <i>(Address)</i>
            </div>
            <div class="form-group">
                <label>Postal Code</label> S<input class="form-control" maxlength="6" name="postal_code" size="6" type="number">
            </div><br>
            <!-- ===== ===== ===== ===== =====
                2. Contacting Details
              ===== ===== ===== ===== ===== -->
            <h3>Contacting Details</h3>
            <div class="form-group">
                <label>Contact Person</label> <input class="form-control" maxlength="20" name="contact_name" size="20" type="text"> <i>(name)</i>
            </div>
            <div class="form-group">
                <label>Relationship with Student</label> <select class="form-control" name="relationship">
                    <option value="">
                        - Select One -
                    </option>
                    <option value="Parent">
                        Parent
                    </option>
                    <option value="Guardian">
                        Guardian
                    </option>
                    <option value="Self">
                        Self
                    </option>
                </select>
            </div>
            <div class="form-group">
                <label>Mobile Phone</label> (+65) <input class="form-control" maxlength="8" name="mobile_phone" size="9" type="number">
            </div>
            <div class="form-group">
                <label>Home Phone <i>(optional)</i></label> (+65) <input class="form-control" maxlength="8" name="home_phone" size="9" type="number"> <i>(in case of emergency)</i>
            </div>
            <div class="form-group">
                <label>Email</label> <input class="form-control" maxlength="60" name="email" size="30" type="email">
            </div>
            <div class="form-group">
                <label>Referral</label> <select class="form-control others" data-target="#referral_others" name="referral">
                    <option value="N.A">
                        N.A
                    </option>
                    <option value="email">
                        Email
                    </option>
                    <option value="facebook">
                        Facebook
                    </option>
                    <option value="flyer">
                        Flyer
                    </option>
                    <option value="magazine">
                        Magazine
                    </option>
                    <option value="newspaper">
                        Newspaper
                    </option>
                    <option value="search engine">
                        Search Engine
                    </option>
                    <option value="twitter">
                        Twitter
                    </option>
                    <option value="others">
                        Others
                    </option>
                </select> <span class="collapse fade" id="referral_others"><input class="form-control" maxlength="50" name="referral_others" size="30" type="text"> <i>(Please specify)</i></span><br>
                <i>How did you find out about us?</i>
            </div><br>
            <!-- ===== ===== ===== ===== =====
                3. Student's Status
              ===== ===== ===== ===== ===== -->
            <h3>Student's Status</h3>
            <div class="form-group">
                <label>Current School</label> <input class="form-control" maxlength="40" name="current_school" size="30" type="text">
            </div>
            <div class="form-group">
                <label>Tutoring Level</label> <select class="form-control others" data-target="#level_others" id="level" name="level">
                    <option value="">
                        - Select One -
                    </option>
                    <option value="Pre-School">
                        Pre-School
                    </option>
                    <option value="Primary 1">
                        Primary 1
                    </option>
                    <option value="Primary 2">
                        Primary 2
                    </option>
                    <option value="Primary 3">
                        Primary 3
                    </option>
                    <option value="Primary 4">
                        Primary 4
                    </option>
                    <option value="Primary 5">
                        Primary 5
                    </option>
                    <option value="Primary 6">
                        Primary 6
                    </option>
                    <option value="Sec 1E">
                        Sec 1 Express
                    </option>
                    <option value="Sec 1N">
                        Sec 1 NT / NA
                    </option>
                    <option value="Sec 2E">
                        Sec 2 Express
                    </option>
                    <option value="Sec 2N">
                        Sec 2 NT / NA
                    </option>
                    <option value="Sec 3E">
                        Sec 3 Express
                    </option>
                    <option value="Sec 3N">
                        Sec 3 NT / NA
                    </option>
                    <option value="Sec 4E">
                        Sec 4 Express
                    </option>
                    <option value="Sec 4N">
                        Sec 4 NT / NA
                    </option>
                    <option value="Sec 5N">
                        Sec 5 NA
                    </option>
                    <option value="IP 1">
                        IP Year 1
                    </option>
                    <option value="IP 2">
                        IP Year 2
                    </option>
                    <option value="IP 3">
                        IP Year 3
                    </option>
                    <option value="IP 4">
                        IP Year 4
                    </option>
                    <option value="IP 5">
                        IP Year 5 (Senior 1)
                    </option>
                    <option value="IP 6">
                        IP Year 6 (Senior 2)
                    </option>
                    <option value="JC 1">
                        JC 1
                    </option>
                    <option value="JC 2">
                        JC 2
                    </option>
                    <option value="Poly">
                        Polytechnic
                    </option>
                    <option value="BAC">
                        Uni (Bachelor)
                    </option>
                    <option value="MAS">
                        Uni (Master)
                    </option>
                    <option value="PhD">
                        Uni (PhD)
                    </option>
                    <option value="Music">
                        Music / Instrument
                    </option>
                    <option value="Language">
                        Foreign Language
                    </option>
                    <option value="others">
                        Others
                    </option>
                </select> <span class="collapse fade" id="level_others"><input class="form-control" maxlength="20" name="level_others" size="20" type="text"> <i>(Please specify)</i></span>
            </div>
            <div class="form-group">
                <label>Subject(s) for Tutoring</label> <input class="form-control" maxlength="60" name="subjects" size="40" type="text">
            </div><br>
            <!-- ===== ===== ===== ===== =====
                4. Preferences
              ===== ===== ===== ===== ===== -->
            <h3>Preferences</h3>
            <div class="form-group">
                <label>Tutor's Gender</label> <select class="form-control" name="gender_preference">
                    <option value="none">
                        No Preference
                    </option>
                    <option value="male">
                        Male
                    </option>
                    <option value="female">
                        Female
                    </option>
                </select>
            </div>
            <div class="form-group">
                <label>Minimal Qualification</label> <select class="form-control" name="qualification_preference">
                    <option value="N/A">
                        No Preference
                    </option>
                    <option value="O-Level">
                        'O' Level
                    </option>
                    <option value="A-Level">
                        'A' Level
                    </option>
                    <option value="Diploma">
                        Diploma
                    </option>
                    <option value="Bachelors">
                        Bachelor
                    </option>
                    <option value="Masters">
                        Master
                    </option>
                    <option value="PhD">
                        PhD
                    </option>
                </select>
            </div>
            <div class="form-group">
                <label>Budget (Tuition Fees)</label> $<input class="form-control" maxlength="5" name="budget_preference" size="5" type="text"> per hour <i>(in Singapore dollars)</i>
            </div>
            <div class="form-group">
                <label>Number of lesson</label> <select class="form-control" name="weekly_lessons">
                    <option value="">
                        - Select One -
                    </option>
                    <option value="1">
                        1
                    </option>
                    <option value="2">
                        2
                    </option>
                    <option value="3">
                        3
                    </option>
                    <option value="4">
                        4
                    </option>
                    <option value="5">
                        5
                    </option>
                    <option value="6">
                        6
                    </option>
                    <option value="7">
                        7
                    </option>
                </select> per week
            </div>
            <div class="form-group">
                <label>Duration</label> <select class="form-control" name="duration">
                    <option value="">
                        - Select One -
                    </option>
                    <option value="1">
                        1 hr
                    </option>
                    <option value="1.5">
                        1.5 hr (recommended)
                    </option>
                    <option value="2">
                        2 hr
                    </option>
                    <option value="2.5">
                        2.5 hr
                    </option>
                    <option value="3">
                        3 hr
                    </option>
                    <option value="0">
                        To be recommended
                    </option>
                </select> per lesson
            </div>
            <div class="form-group">
                <label>Timeslots</label>
                    <div class="form-group">
                        <input id="Monday_morning" name="timeslots[]" type="checkbox" value="Monday Morning"><label for="Monday_morning">Morning</label> <input id="Monday_afternoon" name="timeslots[]" type="checkbox" value="Monday Afternoon"><label for="Monday_afternoon">Afternoon</label> <input id="Monday_evening" name="timeslots[]" type="checkbox" value="Monday Evening"><label for="Monday_evening">Evening</label>
                    </div>
                    <div class="form-group">
                        <input id="Tuesday_morning" name="timeslots[]" type="checkbox" value="Tuesday Morning"><label for="Tuesday_morning">Morning</label> <input id="Tuesday_afternoon" name="timeslots[]" type="checkbox" value="Tuesday Afternoon"><label for="Tuesday_afternoon">Afternoon</label> <input id="Tuesday_evening" name="timeslots[]" type="checkbox" value="Tuesday Evening"><label for="Tuesday_evening">Evening</label>
                    </div>
                    <div class="form-group">
                        <input id="Wednesday_morning" name="timeslots[]" type="checkbox" value="Wednesday Morning"><label for="Wednesday_morning">Morning</label> <input id="Wednesday_afternoon" name="timeslots[]" type="checkbox" value="Wednesday Afternoon"><label for="Wednesday_afternoon">Afternoon</label> <input id="Wednesday_evening" name="timeslots[]" type="checkbox" value="Wednesday Evening"><label for="Wednesday_evening">Evening</label>
                    </div>
                    <div class="form-group">
                        <input id="Thursday_morning" name="timeslots[]" type="checkbox" value="Thursday Morning"><label for="Thursday_morning">Morning</label> <input id="Thursday_afternoon" name="timeslots[]" type="checkbox" value="Thursday Afternoon"><label for="Thursday_afternoon">Afternoon</label> <input id="Thursday_evening" name="timeslots[]" type="checkbox" value="Thursday Evening"><label for="Thursday_evening">Evening</label>
                    </div>
                    <div class="form-group">
                        <input id="Friday_morning" name="timeslots[]" type="checkbox" value="Friday Morning"><label for="Friday_morning">Morning</label> <input id="Friday_afternoon" name="timeslots[]" type="checkbox" value="Friday Afternoon"><label for="Friday_afternoon">Afternoon</label> <input id="Friday_evening" name="timeslots[]" type="checkbox" value="Friday Evening"><label for="Friday_evening">Evening</label>
                    </div>
                    <div class="form-group">
                        <input id="Saturday_morning" name="timeslots[]" type="checkbox" value="Saturday Morning"><label for="Saturday_morning">Morning</label> <input id="Saturday_afternoon" name="timeslots[]" type="checkbox" value="Saturday Afternoon"><label for="Saturday_afternoon">Afternoon</label> <input id="Saturday_evening" name="timeslots[]" type="checkbox" value="Saturday Evening"><label for="Saturday_evening">Evening</label>
                    </div>
                    <div class="form-group">
                        <input id="Sunday_morning" name="timeslots[]" type="checkbox" value="Sunday Morning"><label for="Sunday_morning">Morning</label> <input id="Sunday_afternoon" name="timeslots[]" type="checkbox" value="Sunday Afternoon"><label for="Sunday_afternoon">Afternoon</label> <input id="Sunday_evening" name="timeslots[]" type="checkbox" value="Sunday Evening"><label for="Sunday_evening">Evening</label>
                    </div>
                <i>(Your chance of matching with a home tutor will be higher if you have more available timeslots)</i>
            </div><br>
            <!-- ===== ===== ===== ===== =====
                5. Remarks / Notes for Smart Tuition
              ===== ===== ===== ===== ===== -->
            <h3>Remarks, Notes &amp; Other Requirements</h3>
            <p>To help us to assist you better, do indicate if you have any <b>special requirement or information</b>, such as the student's <b>latest exam results</b>. The more details you give us, the better we can do the matching for you.<br>
            <textarea class="form-control" name="remarks">
</textarea></p><br>
            {{ csrf_field() }} <button type="submit" class="btn btn-default" title="Submit request for tutor"> Submit Request</button>
        </form>
    </div>
</body>
</html>
