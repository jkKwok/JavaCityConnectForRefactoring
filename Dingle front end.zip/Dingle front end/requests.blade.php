@extends("templates.dashboard")

@section("content")
    <h1>Requests </h1>
    <table class="searchResults">
        <tr>
            <th>No.</th>
            <th>Name</th>
            <th>Level</th>
            <th>School</th>
            <th>Location</th>
            <th>Subjects</th>
            <th>Timeslots</th>
            <th>Remarks</th>
            <th>Last Updated</th>
        </tr>
        @if (count($requests) > 0)
            @foreach ($requests as $index=>$student)
                <tr>
                    <td>{{$index + 1 }}</td>
                    <td>
                        <a href = "/student/{{$student->id}}">{{$student->name}}</a>
                        <br />
                        #{{$student->id}}</td>
                    <td>{{$student->level}}</td>
                    <td>{{$student->current_school}}</td>
                    <td>{{$student->address}} S{{$student->postal_code}}
                    <td>{{$student->subjects}}</td>
                    <td>
                        <ul>
                        @if(is_array(unserialize($student->timeslots)))
                            @foreach(unserialize($student->timeslots) as $timeslot)
                                <li>{{$timeslot}}</li>
                            @endforeach
                        @endif
                        </ul>
                    </td>
                    <td>{{$student->remarks}}</td>
                    <td>{{$student->updated_at->format("d M Y h:i")}}</td>
                </tr>
            @endforeach
        @endif
    </table>
@endsection