@extends("templates.dashboard")

@section("content")
    <h1> View/Search Tutors </h1>
    <form method="post" action="/search">
        <h2>Profile</h2>
        <div class="form-group">
            <label for="tutor_id" class="control-label">Tutor ID (Will Overwrite Other Criteria):</label>
            <input type="number" id="tutor_id" name="tutor_id" class="form-control">
        </div>
        <div class="form-group">
            <label for="name" class="control-label">Name / NRIC / Email</label>
            <input type="text" id="name" name="name" class="form-control">
        </div>
        <div class="form-group">
            <label for="phone_number">Phone Number:</label>
            <input type="number" id="phone_number" name="phone_number" class="form-control">
        </div>
        <div class="form-inline">
            <div class="form-group">
                <label for="location">Location:</label>
                <input type="text" name="locations" class="form-control form-inline" />
            </div>
            <div class="form-group">
                <select id="location" name="location" class="form-control">
                    <option value=""></option>
                    <option value="location_most_west">Most West</option>
                    <option value="location_west">West</option>
                    <option value="location_central">Central</option>
                    <option value="location_north">North</option>
                    <option value="location_north_west">North West</option>
                    <option value="location_east">East</option>
                    <option value="location_most_east">Most East</option>
                    <option value="location_north_east">North East</option>
                </select>
            </div>
        </div>
        <h2>Personal Particulars</h2>
        <div class="form-group">
            <label for="nationality">Nationality</label>
            <input type="text" id="nationality" name="nationality" class="form-control">
        </div>
        <div class="checkbox">
            <label>
                <input type="checkbox" id="fulltime" name="occupation" value="Full-Time Tutor">
                Full-Time Tutor
            </label>
        </div>
        <div class="checkbox">
            <label>
                <input type="checkbox" id="teacher" name="occupation" value="School Teacher">
                Current Teacher
            </label>
        </div>
        <div class="form-group">
            <label for="Gender">Gender</label>
        	<select class="form-control" name="gender" class="form-control">
                <option value="">No Preference</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
        	</select>
        </div>
        <div class="form-group form-inline">
            <label for="age_min">Age Range</label>
            <input type="number" id="age_min" name="age_min" class="form-control" placeholder="Min">
            <input type="number" id="age_max" name="age_max" class="form-control" placeholder="Max">
        </div>
        <div class="form-group">
            <label for="experience">Minimum Experience</label>
            <input type="number" id="experience" name="experience" class="form-control">
        </div>

        <h2>Education History</h2>
        <div class="checkbox">
            <label>
                <input type="checkbox" id="nie_graduated" name="nie_graduated" value="true">
                NIE Trained
            </label>

        </div>
        <div class="form-group">
            <label for="qualification">Qualification</label>
            	<select class="form-control" name="highest_qualification">
                    <option value="">- Select One -</option>
                    <option value="O-Level">'O' Level</option>
                    <option value="A-Level">'A' Level</option>
                    <option value="Diploma">Diploma</option>
                    <option value="Bachelors">Bachelor</option>
                    <option value="Masters">Master</option>
                    <option value="PhD">PhD</option>
            	</select>
        </div>
        <div class="form-group">
            <label for="attended_ip_ib"></label>
            <select class="form-control" name="attended_ip_ib" id="attended_ip_ib">
                <option value="">No Preference</option>
                <option value="IP">Integrated Programme (IP)</option>
                <option value="IB">International Baccalaureate (IB)</option>
        	</select>
        </div>
        <div class="form-group">
            <label for="school">School Attended</label>
            <input type="text" id="school" name="school" class="form-control">
        </div>
        <div class="form-group">
            <label for="course">Course Taken</label>
            <input type="text" id="course" name="course" class="form-control">
        </div>

        <h2>Preferences</h2>
        <div class="form-group">
            <label for="maximum_fee">Maximum Fee</label>
            <input type="number" id="" name="" class="form-control">
        </div>
        <div class="form-group">
            <label for="teach_ip">Teach Special Programme</label>
        	<select class="form-control" name="teach_ip">
                <option value="">No Preference</option>
                <option value="IP">IP only</option>
                <option value="IB">IB only</option>
                <option value="Both">IP and IB</option>
        	</select>        </div>

        <h2>Subjects</h2>
        	<legend>Pre-School</legend>
        	<div class = "container-fluid">
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="pre0" value="Pre-School">Pre-School
                    </label>
                </div>
        	</div>

        	<legend>Primary School (PSLE)</legend>
        	<div class = "container-fluid">
                <div class="checkbox">
                    <label class = "col-sm-6">
                        <input type="checkbox" name="subjects[]" id="pri0" value="Chinese">Primary Chinese
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class = "col-sm-6">
                        <input type="checkbox" name="subjects[]" id="pri1" value="English">Primary English
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="pri2" value="Higher Chinese">Primary Higher Chinese
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="pri3" value="Malay">Primary Malay
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="pri4" value="Maths">Primary Math
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="pri5" value="Science">Primary Science
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="pri6" value="Tamil">Primary Tamil
                    </label>
                </div>
        	</div>

        	<legend>'O' Level</legend>
        	<div class = "container-fluid">
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel0" value="A Maths">O-Level A Maths
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel1" value="Accounting">O-Level Accounting
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel2" value="Biology">O-Level Biology
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel3" value="Biology/Chemistry">O-Level Biology/Chemistry
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel4" value="Chemistry">O-Level Chemistry
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel5" value="Chinese">O-Level Chinese
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel6" value="E Maths">O-Level E Maths
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel7" value="English">O-Level English
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel8" value="Geography">O-Level Geography
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel9" value="Higher Chinese">O-Level Higher Chinese
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel10" value="History">O-Level History
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel11" value="Literature">O-Level Literature
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel12" value="Physics">O-Level Physics
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel13" value="Physics/Chemistry">O-Level Physics/Chemistry
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel14" value="Science (lower sec)">O-Level Lower Secondary Science
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel15" value="Malay">O-Level Malay
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel16" value="Tamil">O-Level Tamil
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel17" value="Social Studies">O-Level Social Studies
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel18" value="Hindi">O-Level Hindi
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel19" value="Economics">O-Level Economics
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="oLevel20" value="Business Studies">O-Level Business
                    </label>
                </div>
        
        	</div>

        	<legend>'A' Level</legend>
        	<div class = "container-fluid">
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="aLevel0" value="Accounting">A-Level Accounting
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="aLevel1" value="AO Chinese">A-Level AO Chinese
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="aLevel2" value="Biology">A-Level Biology
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="aLevel3" value="Chemistry">A-Level Chemistry
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="aLevel4" value="Computing">A-Level Computing
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="aLevel5" value="Economics">A-Level Economics
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="aLevel6" value="General Paper (GP)">A-Level General Paper
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="aLevel7" value="Geography">A-Level Geography
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="aLevel8" value="Higher Chinese">A-Level Higher Chinese
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="aLevel9" value="History">A-Level History
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="aLevel10" value="Literature">A-Level Literature
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="aLevel11" value="Maths">A-Level Maths
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="aLevel12" value="Physics">A-Level Physics
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="aLevel13" value="Project Work">A-Level Project Work
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="aLevel14" value="Management of Business">A-Level Management of Business
                    </label>
                </div>
        
        	</div>
        	<legend>Polytechnic and above</legend>
        	<div class = "container-fluid">
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="poly0" value="Accounting">Poly Accounting
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="poly1" value="Business">Poly Business
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="poly2" value="Computing">Poly Computing
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="poly3" value="Engineering Maths">Poly Engineering Maths
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="poly4" value="Management">Poly Management
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="poly5" value="Fine Arts">Poly Fine Arts
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="poly6" value="Human Resource">Poly Human Resource
                    </label>
                </div>

        	</div>

        	<legend>Music</legend>
        	<div class = "container-fluid">
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="music0" value="Clarinet">Clarinet
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="music1" value="Organ">Organ
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="music2" value="Guitar">Guitar
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="music3" value="Piano">Piano
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="music4" value="Saxophone">Saxophone
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="music5" value="Trumpet">Trumpet
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="music6" value="Violin">Violin
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="music7" value="Theory">Music Theory
                    </label>
                </div>

        	</div>
        	<legend>Foreign Language</legend>
        	<div class = "container-fluid">
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="language0" value="French">French
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="language1" value="German">German
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="language2" value="Japanese">Japanese
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="language3" value="Korean">Korean
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="language4" value="Spanish">Spanish
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="language5" value="Tagalog">Tagalog
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="language6" value="Thai">Thai
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="language7" value="Vietnamese">Vietnamese
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="language8" value="English as a Foreign Language">English as a Foreign Language
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="language9" value="Mandarin as a Foreign Language">Mandarin as a Foreign Language
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="language10" value="Malay as a Foreign Language">Malay as a Foreign Language
                    </label>
                </div>
        
                <div class="checkbox">
                    <label class="col-sm-6">
                        <input type="checkbox" name="subjects[]" id="language11" value="Bahasa Indonesia">Bahasa Indonesia
                    </label>
                </div>
        	</div>

        <h2>Others</h2>
        <div class="form-group">
            <label for="status">Profile Status</label>
            <select class="form-control" name="approval">
                <option value="">
                <oprion value="Approved">Approved</oprion>
            </select>
        </div>
        <div class="form-group">
            <label for="self_intro">Tutor's Introduction</label>
            <input type="text" id="self_intro" name="" class="form-control">
        </div>
        <div class="form-group">
            <label for="remarks">Tutor's Remarks</label>
            <input type="text" id="remarks" name="remarks" class="form-control">
        </div>
        <div class="form-group">
            <label for="Location">Admin Comments</label>
            <input type="text" id="comments" name="comments" class="form-control">
        </div>
        {{ csrf_field() }}
        <button type="reset" class="btn btn-danger">Clear Form</button>
        <button type="submit" class="btn btn-primary">Search</button>
    </form>
        <h2>Search Results</h2>
        {!! $tutors->appends($constraints)->render() !!}
        <table class="searchResults">
            <tr>
                <th>No.</th>
                <th>Name</th>
                <th>Ed. Level</th>
                <th>Sec Sch</th>
                <th>Poly/JC</th>
                <th>Uni</th>
                <th>Locations</th>
                <th>Subjects</th>
                <th>Remarks</th>
            </tr>
            @if (count($tutors) > 0)
                @foreach ($tutors as $index=>$tutor)
                    <tr>
                        <td>{{$index + 1 }}</td>
                        <td>
                            <a href = "/tutor/{{$tutor->id}}">{{$tutor->first_name}} {{$tutor->last_name}}</a>
                            <br />
                            #{{$tutor->id}}</td>
                        <td>{{$tutor->highest_qualification}}</td>
                        <td>{{$tutor->secondary_school}}</td>
                        <td>{{$tutor->jc_poly}}
                            <br />
                            <span class="subtext">
                                {{$tutor->jc_poly_course}}
                                @if($tutor->jc_poly_attending)
                                    <br />
                                    (Currently Attending)
                                @endif
                            </span>
                        </td>
                        <td>{{$tutor->university}}
                            <br />
                            <span class="subtext">
                                {{$tutor->university_course}}
                                @if($tutor->university_attending)
                                    <br />
                                    (Currently Attending)
                                @endif
                            </span>
                        </td>
                        <td>
                            {{implode(", ", $tutor->locations())}}
                        </td>
                        <td>
                            <ul>
                                @foreach($tutor->subjects as $subject)
                                    <li>{{$subject->subject_name}}</li>
                                @endforeach
                            </ul>
                        </td>
                        <td>{{$tutor->remarks}}</td>
                    </tr>
                @endforeach
            @endif
        </table>
        <input type="hidden" value="{{$mobile_phone_numbers}}" id="collated-numbers">
        <a class="btn btn-default" id="openCollate">Collate</a>
@endsection
