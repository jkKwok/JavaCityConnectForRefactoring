@extends("templates.basic")

@section("extras")
<script src="/js/jquery.bootstrap.wizard.min.js"></script>
@endsection

@section("content")
<script>
$(function () {
'use strict';
$(() => $(".others").change(function(e){
  if($(this).val() == "others"){
   $($(this).attr("data-target")).collapse("show");
  } else{
   $($(this).attr("data-target")).collapse("hide");
  }
}));
$('#wizard').bootstrapWizard();
$('#signup-form').submit(function () {
  var birth_date = new Date($('#birth_date').val());
  $('#birth_day').val(birth_date.getDate() - 1);
  $('#birth_month').val(birth_date.getMonth());
  $('#birth_year').val(birth_date.getFullYear());
  return true;
});
});
</script>

<style>

#jumbotron {
  background: no-repeat center url(/img/tutor_poster.jpg), #000;
}
</style>

<div class="container-fluid">
  <div class="row">
    <div class="row">
      <div class="col-xs-12 text-center">
        <img src="/img/xlogo.png" style="width:100px">
      </div>
    </div>
    <div class="row">&nbsp;</div>
    <div class="row">
      <div class="col-xs-12">
        <div class="jumbotron text-center"
          id="jumbotron">
        </div>
      </div>
    </div>
    <div class="row separator"></div>
    <div class="row">
      <div class="col-xs-12">
        <form method="post" action="/signup" style="margin:4em" id="signup-form">
          <input type="hidden" name="birth_day" id="birth_day">
          <input type="hidden" name="birth_month" id="birth_month">
          <input type="hidden" name="birth_year" id="birth_year">
          <div id="wizard">
            <div class="navbar">
              <div class="navbar-inner">
                <div class="container">
                  <ul>
                    <li><a href="#tab1" data-toggle="tab">Personal Particulars</a></li>
                    <li><a href="#tab2" data-toggle="tab">Contact Details</a></li>
                    <li><a href="#tab3" data-toggle="tab">Education Records</a></li>
                    <li><a href="#tab4" data-toggle="tab">Self Introduction</a></li>
                    <li><a href="#tab5" data-toggle="tab">Preferences</a></li>
                    <li><a href="#tab6" data-toggle="tab">Tutoring Locations</a></li>
                    <li><a href="#tab7" data-toggle="tab">Tutoring Level and Subjects</a></li>
                    <li><a href="#tab8" data-toggle="tab">Others</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="tab-content">
              <div class="tab-pane" id="tab1">
                <h3>Personal Particulars</h3>
                <p class="text-center">
                  IC number, birth date and occupation will be kept private.
                </p>
                <div class="form-group">
                  <label>First Name</label>
                  <input class="form-control" type="text" name="first_name"
                    placeholder="First Name">
                </div>
                <div class="form-group">
                  <label>Surname Name</label>
                  <input class="form-control" type="text" name="last_name" placeholder="Surname Name">
                </div>
                <div class="form-group">
                  <label>NRIC / FIN</label>
                  <input class="form-control" type="text" name="nric" placeholder="NRIC / FIN">
                </div>
                <div class="form-group">
                  <label>Date of Birth</label>
                  <input class="form-control" type="date" id="birth_date"
                  placeholder="Date of Birth">
                </div>
                <div class="form-group">
                  <label>Gender</label>
                  <select class="form-control" type="text" name="gender">
                    <option value>-- Select one --</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                  </select>
                </div>
                <div class="form-group">
                  <label>Nationality</label>
                  <select class="form-control others" type="text" name="nationality"
                    data-target="#nationality_other">
                    <option value>-- Select one --</option>
                    <option value="Singaporean">Singaporean</option>
                    <option value="American">American</option>
                    <option value="Australian">Australian</option>
                    <option value="British">British</option>
                    <option value="Canadian">Canadian</option>
                    <option value="Filipino">Filipino</option>
                    <option value="German">German</option>
                    <option value="Indian">Indian</option>
                    <option value="Indonesian">Indonesian</option>
                    <option value="Malaysian">Malaysian</option>
                    <option value="Chinese">Chinese</option>
                    <option value="Taiwanese">Taiwanese</option>
                    <option value="Thai">Thai</option>
                    <option value="Vietnamese">Vietnamese</option>
                    <option value="others">Others</option>
                  </select>
                </div>
                <div class="form-group">
                  <span class="collapse fade" id="nationality_other">
                    <input type="text" class="form-control" maxlength="20" name="nationality_other" size="20">
                    <i>(Please specify)</i>
                  </span>
                </div>
                <div class="form-group">
                  <label>Race</label>
                  <select class="others form-control" data-target="#race_other" name="race">
                    <option value>
                      - Select One -
                    </option>
                    <option value="Chinese">
                      Chinese
                    </option>
                    <option value="Malay">
                      Malay
                    </option>
                    <option value="Indian">
                      Indian
                    </option>
                    <option value="Eurasian">
                      Eurasian
                    </option>
                    <option value="others">
                      Others
                    </option>
                  </select>
                </div>
                <div class="form-group">
                  <span class="collapse fade" id="race_other">
                    <input class="form-control" maxlength="20" name="race_other"
                    size="20" type="text">
                    <i>(Please specify)</i>
                  </span>
                </div>
                <div class="form-group">
                  <label>Full-time Occupation</label>
                  <select class="others form-control" data-target="#occupation_other"
                  name="occupation">
                    <option value>
                      - Select One -
                    </option>
                    <option value="Full-Time Tutor">
                      Full-Time Tutor
                    </option>
                    <option value="School Teacher">
                      School Teacher
                    </option>
                    <option value="NIE Trainee">
                      NIE Trainee
                    </option>
                    <option value="Undergraduate">
                      Undergraduate
                    </option>
                    <option value="Poly Student">
                      Poly Student
                    </option>
                    <option value="JC Student">
                      JC Student
                    </option>
                    <option value="NSF">
                      NSF
                    </option>
                    <option value="others">
                      Others
                    </option>
                  </select>
                </div>
                <div class="form-group">
                  <span class="collapse fade" id="occupation_other">
                    <input class="form-control" maxlength="30" name="occupation_other"
                    size="20" type="text">
                    <i>(Please specify)</i>
                  </span>
                </div>
              </div>
              <div class="tab-pane" id="tab2">
                <h3>Contact Details</h3>
                <p class="text-center">
                  All contact details will be kept private.
                </p>
                <div class="form-group">
                  <label>Email Address</label>
                  <input class="form-control" maxlength="60" name="email"
                    onblur="updateEmail(this.value)"
                    onchange="updateEmail(this.value)"
                    onkeyup="updateEmail(this.value)"
                    size="40"
                    type="text">
                </div>
                <div class="form-group">
                  <label>Mobile Phone</label>
                  <div class="input-group">
                    <span class="input-group-addon">(+65)</span>
                    <input class="form-control" maxlength="8" name="mobile_phone" size="9" type="text">
                  </div>
                  <i>(No space in between)</i>
                </div>
                <div class="form-group">
                  <label>Home Phone<i>(optional)</i></label>
                  <div class="input-group">
                    <span class="input-group-addon">(+65)</span>
                    <input class="form-control" maxlength="8" name="home_phone" size="9"
                      type="text">
                  </div>
                  <i>(For emergency only)</i>
                </div>
                <div class="form-group">
                  <label>Home Address</label>
                  <input class="form-control" maxlength="50" name="address" size="40"
                    type="text">
                </div>
                <div class="form-group">
                  <label>Postal Code</label>
                  <div class="input-group">
                    <span class="input-group-addon">S</span>
                    <input class="form-control" maxlength="6" name="postal_code"
                      size="6" type="text">
                  </div>
                </div>
              </div>
              <div class="tab-pane" id="tab3">
                <h3>Education Records</h3>
                <p>
                  These are your education records and NOT preferences.<br>
                  If you are an undergraduate, your high qualification is either 'A' level or Diploma.<br>
                  If you are taking 'A' level or Diploma, your high qualification is at most 'O' level.
                </p>
                <div class="form-group">
                  <label>Highest Qualification</label>
                  <select class="form-control" name="highest_qualification">
                      <option value="">
                        - Select One -
                      </option>
                      <option value="O-Level">
                        'O' Level
                      </option>
                      <option value="A-Level">
                        'A' Level
                      </option>
                      <option value="Diploma">
                        Diploma
                      </option>
                      <option value="Bachelors">
                        Bachelor
                      </option>
                      <option value="Masters">
                        Master
                      </option>
                      <option value="PhD">
                        PhD
                      </option>
                    </select>
                    <i>(You will need to submit your final official certificate)</i>
                  </div>
                <div class="form-group">
                  <label>Graduated from NIE</label>
                  <select class="form-control" name="nie_graduated">
                    <option value="true">
                      Yes
                    </option>
                    <option selected value="false">
                      No
                    </option>
                  </select>
                  <i>
                    (You will need to submit your final official certificate issued by NIE)
                  </i>
                </div>
                <div class="form-group">
                  <label>Attending/Attended IP</label>
                  <select class="form-control" name="attended_ip_ib">
                    <option value>
                      No
                    </option>
                    <option value="IP">
                      Integrated Programme (IP)
                    </option>
                    <option value="IB">
                      International Baccalaureate (IB)
                    </option>
                  </select>
                  <i>(You will need to submit your year 4 result)</i>
                </div>
                <div class="form-group">
                  <label>Tutoring Experience</label>
                  <select class="form-control" name="experience">
                    <option value="-1">
                        No Experience
                    </option>
                    <option value="0">
                        &lt; 1 year
                    </option>
                    <option value="1">
                        &gt; 1 year
                    </option>
                    <option value="2">
                        &gt; 2 years
                    </option>
                    <option value="3">
                        &gt; 3 years
                    </option>
                    <option value="4">
                        &gt; 4 years
                    </option>
                    <option value="5">
                        &gt; 5 years
                    </option>
                    <option value="6">
                        &gt; 6 years
                    </option>
                    <option value="7">
                        &gt; 7 years
                    </option>
                    <option value="8">
                        &gt; 8 years
                    </option>
                    <option value="9">
                        &gt; 9 years
                    </option>
                    <option value="10">
                        &gt; 10 years
                    </option>
                    <option value="11">
                        &gt; 11 years
                    </option>
                    <option value="12">
                        &gt; 12 years
                    </option>
                    <option value="13">
                        &gt; 13 years
                    </option>
                    <option value="14">
                        &gt; 14 years
                    </option>
                    <option value="15">
                        &gt; 15 years
                    </option>
                    <option value="16">
                        &gt; 16 years
                    </option>
                    <option value="17">
                        &gt; 17 years
                    </option>
                    <option value="18">
                        &gt; 18 years
                    </option>
                    <option value="19">
                        &gt; 19 years
                    </option>
                    <option value="20">
                        &gt; 20 years
                    </option>
                    <option value="21">
                        &gt; 21 years
                    </option>
                    <option value="22">
                        &gt; 22 years
                    </option>
                    <option value="23">
                        &gt; 23 years
                    </option>
                    <option value="24">
                        &gt; 24 years
                    </option>
                    <option value="25">
                        &gt; 25 years
                    </option>
                    <option value="26">
                        &gt; 26 years
                    </option>
                    <option value="27">
                        &gt; 27 years
                    </option>
                    <option value="28">
                        &gt; 28 years
                    </option>
                    <option value="29">
                        &gt; 29 years
                    </option>
                    <option value="30">
                        &gt; 30 years
                    </option>
                    <option value="31">
                        &gt; 31 years
                    </option>
                    <option value="32">
                        &gt; 32 years
                    </option>
                    <option value="33">
                        &gt; 33 years
                    </option>
                    <option value="34">
                        &gt; 34 years
                    </option>
                    <option value="35">
                        &gt; 35 years
                    </option>
                    <option value="36">
                        &gt; 36 years
                    </option>
                    <option value="37">
                        &gt; 37 years
                    </option>
                    <option value="38">
                        &gt; 38 years
                    </option>
                    <option value="39">
                        &gt; 39 years
                    </option>
                    <option value="40">
                        &gt; 40 years
                    </option>
                    <option value="41">
                        &gt; 41 years
                    </option>
                    <option value="42">
                        &gt; 42 years
                    </option>
                    <option value="43">
                        &gt; 43 years
                    </option>
                    <option value="44">
                        &gt; 44 years
                    </option>
                    <option value="45">
                        &gt; 45 years
                    </option>
                    <option value="46">
                        &gt; 46 years
                    </option>
                    <option value="47">
                        &gt; 47 years
                    </option>
                    <option value="48">
                        &gt; 48 years
                    </option>
                    <option value="49">
                        &gt; 49 years
                    </option>
                    <option value="50">
                        &gt; 50 years
                    </option>
                    <option value="51">
                        &gt; 51 years
                    </option>
                    <option value="52">
                        &gt; 52 years
                    </option>
                    <option value="53">
                        &gt; 53 years
                    </option>
                    <option value="54">
                        &gt; 54 years
                    </option>
                    <option value="55">
                        &gt; 55 years
                    </option>
                    <option value="56">
                        &gt; 56 years
                    </option>
                    <option value="57">
                        &gt; 57 years
                    </option>
                    <option value="58">
                        &gt; 58 years
                    </option>
                    <option value="59">
                        &gt; 59 years
                    </option>
                    <option value="60">
                        &gt; 60 years
                    </option>
                    <option value="61">
                        &gt; 61 years
                    </option>
                    <option value="62">
                        &gt; 62 years
                    </option>
                    <option value="63">
                        &gt; 63 years
                    </option>
                    <option value="64">
                        &gt; 64 years
                    </option>
                    <option value="65">
                        &gt; 65 years
                    </option>
                    <option value="66">
                        &gt; 66 years
                    </option>
                    <option value="67">
                        &gt; 67 years
                    </option>
                    <option value="68">
                        &gt; 68 years
                    </option>
                    <option value="69">
                        &gt; 69 years
                    </option>
                    <option value="70">
                        &gt; 70 years
                    </option>
                  </select>
                </div>
                <div class="form-group">
                  <label>Secondary School</label>
                  <input class="form-control" maxlength="40" name="secondary_school"
                    size="30" type="text">
                  <i>(School Name)</i>
                </div>
                <div class="form-group">
                  <label>JC / Poly</label>
                  <input class="form-control" maxlength="40" name="jc_poly" size="30"
                    type="text">
                  <i>(School Name)</i>
                </div>
                <div class="form-group">
                  <input class="form-control" maxlength="40" name="jc_poly_course"
                    size="30" type="text">
                  <i>(Course / Major)</i>
                </div>
                <div class="form-group">
                  <input id="attendingJCPoly" name="jc_poly_attending" type="checkbox"
                    value="true">
                  <label for="attendingJCPoly">Currently attending</label>
                </div>
                <div class="form-group">
                  <label>University<i>(if applicable)</i></label>
                  <input class="form-control" maxlength="40" name="university"
                    size="30" type="text">
                  <i>(School Name)</i>
                </div>
                <div class="form-group">
                  <input class="form-control" maxlength="40" name="university_course"
                    size="30" type="text">
                  <i>(Course / Major)</i>
                </div>
                <div class="form-group">
                  <input id="university_attending" name="university_attending"
                    type="checkbox" value="true">
                  <label>Currently attending</label>
                </div>
                <div class="form-group">
                  <label>
                    'O' &amp; 'A' level Results
                    <i>(or IP year 4 or diploma GPA)</i>
                  </label>
                  <textarea class="form-control" name="results"></textarea>
                </div>
              </div>
              <div class="tab-pane" id="tab4">
                <h3>Self Introduction</h3>
                <p>
                  Tell parents/students why they should choose you as their home tutor
                  to stand out from the rest of the tutors who hold the same
                  qualification as you. You may indicate your past tutoring experience,
                  teaching methods, achievements, awards and professional
                  certificates... etc.<br>
                  <br>
                  <b>Strictly no contact information (email, phone number, website) to be stated here.</b>
                </p>
                <div class="form-group">
                  <textarea name="self_intro" class="form-control"></textarea>
                </div>
              </div>
              <div class="tab-pane" id="tab5">
                <h3>Preferences</h3>
                <p>Let us know your expectation and choices.</p>
                <div class="form-group">
                  <label>Minimal Expected rates</label>
                  $
                  <select class="form-control" id="feeRange" name="minimal_amount"
                    size="1">
                    <option value="0">
                        N.A
                    </option>
                    <option value="10">
                        10
                    </option>
                    <option value="15">
                        15
                    </option>
                    <option value="20">
                        20
                    </option>
                    <option value="25">
                        25
                    </option>
                    <option value="30">
                        30
                    </option>
                    <option value="35">
                        35
                    </option>
                    <option value="40">
                        40
                    </option>
                    <option value="45">
                        45
                    </option>
                    <option value="50">
                        50
                    </option>
                    <option value="55">
                        55
                    </option>
                    <option value="60">
                        60
                    </option>
                    <option value="65">
                        65
                    </option>
                    <option value="70">
                        70
                    </option>
                    <option value="75">
                        75
                    </option>
                    <option value="80">
                        80
                    </option>
                    <option value="85">
                        85
                    </option>
                    <option value="90">
                        90
                    </option>
                    <option value="95">
                        95
                    </option>
                    <option value="100">
                        100
                    </option>
                  </select>
                  <i>(SGD per hour)</i>
                </div>
                <div class="form-group">
                  <label>Student's Gender</label>
                  <select class="form-control" name="gender_preference">
                    <option value="No Preference">
                        No Preference
                    </option>
                    <option value="Male">
                        Male
                    </option>
                    <option value="Female">
                        Female
                    </option>
                  </select>
                </div>
                <div class="form-group">
                  <label>Teach IP students?</label>
                  <select class="form-control" name="teach_ip">
                    <option value="No">
                        No
                    </option>
                    <option value="IP">
                        IP only
                    </option>
                    <option value="IB">
                        IB only
                    </option>
                    <option value="Both">
                        IP and IB
                    </option>
                  </select>
                </div>
              </div>
              <div class="tab-pane" id="tab6">
                <h3>Tutoring Locations</h3>
                <p>Grouped according to Singapore MRT system</p>
                <div class="form-group">
                  <input id="location0" name="location_most_west" type="checkbox" value="true">
                  <label>
                    Most West<br>
                    (Joo Koon, Pioneer, Boon Lay, Lakeside, Chinese Garden, Jurong East)
                  </label>
                </div>
                <div class="form-group">
                  <input id="location0" name="location_west" type="checkbox" value="true">
                  <label>
                    West<br>
                    (Clementi, Dover, Buona Vista, Commonwealth, Queenstown, Redhill, Tiong Bahru, Outram Park, Tanjong Pagar)
                  </label>
                </div>
                <div class="form-group">
                  <input id="location0" name="location_central" type="checkbox" value="true">
                  <label>
                    Central/City<br>
                    (Chinatown, Clarke Quay, Raffles Place, City Hall, Dhoby Ghaut, Somerset, Orchard, Newton, Novena, Toa Payoh, Braddell)
                  </label>
                </div>
                <div class="form-group">
                  <input id="location0" name="location_north" type="checkbox" value="true">
                  <label>
                    North<br>
                    (Bishan, Ang Mo Kio, Yio Chu Kang, Khatib, Yishun, Sembawang, Admiralty, Woodlands, Marsiling, Kranji)
                  </label>
                </div>
                <div class="form-group">
                  <input id="location0" name="location_north_west" type="checkbox" value="true">
                  <label>
                    North West<br>
                    (Yew Tee, Choa Chu Kang, Bukit Gombak, Bukit Batok)
                  </label>
                </div>
                <div class="form-group">
                  <input id="location0" name="location_east" type="checkbox" value="true">
                  <label>
                    East<br>
                    (Bugis, Lavender, Kallang, Aljunied, Paya Lebar, Eunos, Kembangan)
                  </label>
                </div>
                <div class="form-group">
                  <input id="location0" name="location_most_east" type="checkbox" value="true">
                  <label>
                    Most East<br>
                    (Bedok, Tanah Merah, Expo, Changi, Simei, Tampiness, Pasir Ris)
                  </label>
                </div>
                <div class="form-group">
                  <input id="location0" name="location_north_east" type="checkbox" value="true">
                  <label>
                    North East<br>
                    (Little India, Farrer Park, Boon Keng, Potong Pasir, Woodleigh, Serangoon, Kovan, Hougang, Buangkok, Sengkang, Punggol)
                  </label>
                </div>
              </div>
              <div class="tab-pane" id="tab7">
                <h2>Tutoring Level and subjects</h2>
                <p><i>(Indicate only subjects that you are confident to deliver)</i></p>
                <div class="form-group container-fluid">
                  <div class="col-sm-12"><b>Pre-School</b></div>
                  <div class="checkbox col-sm-12">
                    <input id="pre0" name="subjects[]" type="checkbox" value="Pre-School">
                    <label>Pre-School</label>
                  </div>
                </div>
                <div class="form-group container-fluid">
                  <div class="col-sm-12"><b>Primary School (PSLE)</b></div>
                  <div class="checkbox col-sm-6">
                    <input id="pri0" name="subjects[]" type="checkbox" value="Chinese">
                    <label>Primary Chinese</label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="pri1" name="subjects[]" type="checkbox" value="English">
                    <label>Primary English</label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="pri2" name="subjects[]" type="checkbox" value="Higher Chinese">
                    <label>
                      Primary Higher Chinese
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="pri3" name="subjects[]" type="checkbox" value="Malay">
                    <label>
                      Primary Malay
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="pri4" name="subjects[]" type="checkbox" value="Maths">
                    <label>
                      Primary Math
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="pri5" name="subjects[]" type="checkbox" value="Science">
                    <label>
                      Primary Science
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="pri6" name="subjects[]" type="checkbox" value="Tamil">
                    <label>
                      Primary Tamil
                    </label>
                  </div>
                </div>
                <div class="form-group container-fluid">
                  <div class="col-md-12"><b>'O' Level</b></div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel0" name="subjects[]" type="checkbox" value="A Maths">
                    <label>
                      O-Level A Maths
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel1" name="subjects[]" type="checkbox" value="Accounting">
                    <label>
                      O-Level Accounting
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel2" name="subjects[]" type="checkbox" value="Biology">
                    <label>
                      O-Level Biology
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel3" name="subjects[]" type="checkbox" value="Biology/Chemistry">
                    <label>
                      O-Level Biology/Chemistry
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel4" name="subjects[]" type="checkbox" value="Chemistry">
                    <label>
                      O-Level Chemistry
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel5" name="subjects[]" type="checkbox" value="Chinese">
                    <label>
                      O-Level Chinese
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel6" name="subjects[]" type="checkbox" value="E Maths">
                    <label>
                      O-Level E Maths
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel7" name="subjects[]" type="checkbox" value="English">
                    <label>
                      O-Level English
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel8" name="subjects[]" type="checkbox" value="Geography">
                    <label>
                      O-Level Geography
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel9" name="subjects[]" type="checkbox" value="Higher Chinese">
                    <label>
                      O-Level Higher Chinese
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel10" name="subjects[]" type="checkbox" value="History">
                    <label>
                      O-Level History
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel11" name="subjects[]" type="checkbox" value="Literature">
                    <label>
                      O-Level Literature
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel12" name="subjects[]" type="checkbox" value="Physics">
                    <label>
                      O-Level Physics
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel13" name="subjects[]" type="checkbox" value="Physics/Chemistry">
                    <label>
                      O-Level Physics/Chemistry
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel14" name="subjects[]" type="checkbox" value="Science (lower sec)">
                    <label>
                      O-Level Lower Secondary Science
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel15" name="subjects[]" type="checkbox" value="Malay">
                    <label>
                      O-Level Malay
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel16" name="subjects[]" type="checkbox" value="Tamil">
                    <label>
                      O-Level Tamil
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel17" name="subjects[]" type="checkbox" value="Social Studies">
                    <label>
                      O-Level Social Studies
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel18" name="subjects[]" type="checkbox" value="Hindi">
                    <label>
                      O-Level Hindi
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel19" name="subjects[]" type="checkbox" value="Economics">
                    <label>
                      O-Level Economics
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="oLevel20" name="subjects[]" type="checkbox" value="Business Studies">
                    <label>
                      O-Level Business
                    </label>
                  </div>
                </div>
                <div class="form-group container-fluid">
                  <div class="col-md-12"><b>'A' Level</b></div>
                  <div class="checkbox col-sm-6">
                    <input id="aLevel0" name="subjects[]" type="checkbox" value="Accounting">
                    <label>
                      A-Level Accounting
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="aLevel1" name="subjects[]" type="checkbox" value="AO Chinese">
                    <label>
                      A-Level AO Chinese
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="aLevel2" name="subjects[]" type="checkbox" value="Biology">
                    <label>
                      A-Level Biology
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="aLevel3" name="subjects[]" type="checkbox" value="Chemistry">
                    <label>
                      A-Level Chemistry
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="aLevel4" name="subjects[]" type="checkbox" value="Computing">
                    <label>
                      A-Level Computing
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="aLevel5" name="subjects[]" type="checkbox" value="Economics">
                    <label>
                      A-Level Economics
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="aLevel6" name="subjects[]" type="checkbox" value="General Paper (GP)">
                    <label>
                      A-Level General Paper
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="aLevel7" name="subjects[]" type="checkbox" value="Geography">
                    <label>
                      A-Level Geography
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="aLevel8" name="subjects[]" type="checkbox" value="Higher Chinese">
                    <label>
                      A-Level Higher Chinese
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="aLevel9" name="subjects[]" type="checkbox" value="History">
                    <label>
                      A-Level History
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="aLevel10" name="subjects[]" type="checkbox" value="Literature">
                    <label>
                      A-Level Literature
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="aLevel11" name="subjects[]" type="checkbox" value="Maths">
                    <label>
                      A-Level Maths
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="aLevel12" name="subjects[]" type="checkbox" value="Physics">
                    <label>
                      A-Level Physics
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="aLevel13" name="subjects[]" type="checkbox" value="Project Work">
                    <label>
                      A-Level Project Work
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="aLevel14" name="subjects[]" type="checkbox" value="Management of Business">
                    <label>
                      A-Level Management of Business
                    </label>
                  </div>
                </div>
                <div class="form-group container-fluid">
                  <div class="col-md-12"><b>Polytechnic and above</b></div>
                  <div class="checkbox col-sm-6">
                    <input id="poly0" name="subjects[]" type="checkbox" value="Accounting">
                    <label>
                      Poly Accounting
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="poly1" name="subjects[]" type="checkbox" value="Business">
                    <label>
                      Poly Business
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="poly2" name="subjects[]" type="checkbox" value="Computing">
                    <label>
                      Poly Computing
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="poly3" name="subjects[]" type="checkbox" value="Engineering Maths">
                    <label>
                      Poly Engineering Maths
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="poly4" name="subjects[]" type="checkbox" value="Management">
                    <label>
                      Poly Management
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="poly5" name="subjects[]" type="checkbox" value="Fine Arts">
                    <label>
                      Poly Fine Arts
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="poly6" name="subjects[]" type="checkbox" value="Human Resource">
                    <label>
                      Poly Human Resource
                    </label>
                  </div>
                </div>
                <div class="form-group container-fluid">
                  <div class="col-md-12"><b>Music</b></div>
                  <div class="checkbox col-sm-6">
                    <input id="music0" name="subjects[]" type="checkbox" value="Clarinet">
                    <label>
                      Clarinet
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="music1" name="subjects[]" type="checkbox" value="Organ">
                    <label>
                      Organ
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="music2" name="subjects[]" type="checkbox" value="Guitar">
                    <label>
                      Guitar
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="music3" name="subjects[]" type="checkbox" value="Piano">
                    <label>
                      Piano
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="music4" name="subjects[]" type="checkbox" value="Saxophone">
                    <label>
                      Saxophone
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="music5" name="subjects[]" type="checkbox" value="Trumpet">
                    <label>
                      Trumpet
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="music6" name="subjects[]" type="checkbox" value="Violin">
                    <label>
                      Violin
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="music7" name="subjects[]" type="checkbox" value="Theory">
                    <label>
                      Music Theory
                    </label>
                  </div>
                </div>
                <div class="form-group container-fluid">
                  <div class="col-md-12"><b>Foreign Language</b></div>
                  <div class="checkbox col-sm-6">
                    <input id="language0" name="subjects[]" type="checkbox" value="French">
                    <label>
                      French
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="language1" name="subjects[]" type="checkbox" value="German">
                    <label>
                      German
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="language2" name="subjects[]" type="checkbox" value="Japanese">
                    <label>
                      Japanese
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="language3" name="subjects[]" type="checkbox" value="Korean">
                    <label>
                      Korean
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="language4" name="subjects[]" type="checkbox" value="Spanish">
                    <label>
                      Spanish
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="language5" name="subjects[]" type="checkbox" value="Tagalog">
                    <label>
                      Tagalog
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="language6" name="subjects[]" type="checkbox" value="Thai">
                    <label>
                      Thai
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="language7" name="subjects[]" type="checkbox" value="Vietnamese">
                    <label>
                      Vietnamese
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="language8" name="subjects[]" type="checkbox" value="English as a Foreign Language">
                    <label>
                      English as a Foreign Language
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="language9" name="subjects[]" type="checkbox" value="Mandarin as a Foreign Language">
                    <label>
                      Mandarin as a Foreign Language
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="language10" name="subjects[]" type="checkbox" value="Malay as a Foreign Language">
                    <label>
                      Malay as a Foreign Language
                    </label>
                  </div>
                  <div class="checkbox col-sm-6">
                    <input id="language11" name="subjects[]" type="checkbox" value="Bahasa Indonesia">
                    <label>
                      Bahasa Indonesia
                    </label>
                  </div>
                </div>
              </div>
              <div class="tab-pane" id="tab8">
                <h3>Others</h3>
                <p>State in "Comments for coordinators" below</p>
                <div class="form-group">
                  <label>Comments for coordinators</label>
                  <textarea class="form-control" name="remarks"></textarea><br>
                  <i>(visible only to our administrators and coordinators)</i><br>
                  <br>
                  <i>Do indicate if you have any constraint or feedback, including if you are only looking for tuition in a certain district or you have allergic to animals' fur.<br>
                  <br>
                  As far as possible, please keep this column empty.<br>
                  <br>
                  For enquiries, please use the <a href="/home">contact us</a> form instead.</i>
                </div>
                <input type="submit" class="btn btn-default" value="Register as a Tutor!">
                &nbsp;<br>&nbsp;<br>
                <span style="color:#f00">
                  Do not register if you do not intend to submit your document for verification.
                </span>
              </div>
              <ul class="pager wizard">
                <li class="previous"><a href="#wizard">Previous</a></li>
                <li class="next"><a href="#wizard">Next</a></li>
              </ul>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
@endsection
