@extends("templates.dashboard")

@section("content")
<form action="/student/{{$student->id}}/details" method="post">
    <div id="tutorDetails">
        <h1>{{$student->name}} (ID: {{$student->id}})</h1>
        <div class="container-fluid">
            <table>
                <tr>
                    <th>Birth Year</th>
                        <td>
                            <span class="subtext">
                              {!!
                                  Form::text(
                                    'birth_year',
                                    $student->birth_year,
                                    ['id' => 'birth_year', 'class' => 'form-control'])
                                !!}
                            </span>
                            ({{$student->age()}} Years Old)
                            </td>
                    <th>Gender</th>
                    <td>
                      <select class="form-control" name="gender">
                        <option
                          {{
                            $student->gender === 'male'
                            || $student->gender === 'female' ? '' : 'selected'
                          }}>
                          - Select One -
                        </option>
                        <option value="male" {{ $student->gender === 'male' ? 'selected' : '' }}>Male</option>
                        <option value="female" {{ $student->gender === 'female' ? 'selected' : '' }}>Female</option>
                      </select>
                    </td>
                </tr>
                <tr>
                    <th>Nationality</th>
                    <td>{!!
                      Form::text(
                        'nationality',
                        $student->nationality,
                        ['id' => 'nationality', 'class' => 'form-control',
                        'placeholder' => 'Nationality'])
                        !!}</td>
                    <th>Race</th>
                    <td>{!!
                      Form::text(
                        'race',
                        $student->race,
                        ['id' => 'race', 'class' => 'form-control',
                        'placeholder' => 'Race'])
                        !!}</td>
                </tr>
                <tr>
                    <th>Level</th>
                    <td>{!!
                      Form::text(
                        'level',
                        $student->level,
                        ['id' => 'level', 'class' => 'form-control',
                        'placeholder' => 'Level'])
                        !!}</td>
                    <th>Current School</th>
                    <td>{!!
                      Form::text(
                        'current_school',
                        $student->current_school,
                        ['id' => 'current_school', 'class' => 'form-control',
                        'placeholder' => 'Current School'])
                        !!}</td>
                </tr>
            </table>
        </div>
        <div class="container-fluid">
            <h2>Contact Details</h2>
            <table>
                <tr>
                    <th>Email</th>
                    <td>{!!
                      Form::text(
                        'email',
                        $student->email,
                        ['id' => 'email', 'class' => 'form-control',
                        'placeholder' => 'Email'])
                        !!}</td>
                </tr>
                <tr>
                    <th>Mobile Phone</th>
                    <td>{!!
                      Form::text(
                        'mobile_phone',
                        $student->mobile_phone,
                        ['id' => 'mobile_phone', 'class' => 'form-control',
                        'placeholder' => 'Mobile Phone'])
                        !!}</td>
                </tr>
                <tr>
                    <th>Home Phone</th>
                    <td>{!!
                      Form::text(
                        'home_phone',
                        $student->home_phone,
                        ['id' => 'home_phone', 'class' => 'form-control',
                        'placeholder' => 'Home Phone'])
                        !!}</td>
                </tr>
                <tr>
                    <th>Address</th>
                    <td>{!!
                      Form::text(
                        'location',
                        $student->location,
                        ['id' => 'location', 'class' => 'form-control',
                        'placeholder' => 'Location'])
                        !!}</td>
                </tr>
                <tr>
                    <th>Postal Code</th>
                    <td>{!!
                      Form::text(
                        'postal_code',
                        $student->postal_code,
                        ['id' => 'postal_code', 'class' => 'form-control',
                        'placeholder' => 'Postal Code'])
                      !!}</td>
                </tr>
            </table>
        </div>
        <div class="container-fluid">
            <h2>Preferences</h2>
            <table>
                <tr>
                    <th>Qualification</th>
                    <td>{!!
                      Form::text(
                        'qualification_preference',
                        $student->qualification_preference,
                        ['id' => 'qualification_preference', 'class' => 'form-control',
                        'placeholder' => 'Qualification'])
                      !!}</td>
                </tr>
                <tr>
                    <th>Budget</th>
                    <td>{!!
                      Form::text(
                        'budget_preference',
                        $student->budget_preference,
                        ['id' => 'budget_preference', 'class' => 'form-control',
                        'placeholder' => 'Budget'])
                      !!}</td>
                </tr>
                <tr>
                    <th>Tutor's Gender</th>
                    <td>{!!
                      Form::text(
                        'gender_preference',
                        $student->gender_preference,
                        ['id' => 'gender_preference', 'class' => 'form-control',
                        'placeholder' => 'Tutor\'s Gender'])
                      !!}</td>
                </tr>
                <tr>
                    <th>Duration</th>
                    <td>
                      {!!
                        Form::text(
                          'duration',
                          $student->duration,
                          ['id' => 'duration', 'class' => 'form-control',
                          'placeholder' => 'Duration'])
                        !!}</td>
                </tr>
                <tr>
                    <th>Timeslots</th>
                    <td><ul>
                        @if(is_array(unserialize($student->timeslots)))
                            @foreach(unserialize($student->timeslots) as $timeslot)
                                <li>{{$timeslot}}</li>
                            @endforeach
                        @endif
                    </ul></td>
                </tr>
                <tr>
                    <th>Subjects</th>
                    <td>{!!
                      Form::text(
                        'subjects',
                        $student->subjects,
                        ['id' => 'subjects', 'class' => 'form-control',
                        'placeholder' => 'Subjects'])
                      !!}</td>
                </tr>
            </table>
        </div>
        <div class="container-fluid">
            <h2>Comments for Coordinators</h2>
            <pre>{!!
              Form::text(
                'remarks',
                $student->remarks,
                ['id' => 'remarks', 'class' => 'form-control',
                'placeholder' => 'Remarks'])
              !!}</pre>
            <table>
                <tr>
                    <th>Referral</th>
                    <td>{{$student->referral}}</td>
                </tr>
            </table>
        </div>
        <div class="container-fluid">
          <input type="submit" class="btn btn-default" value="Save Details">
        </div>
</form>
        <div class="container-fluid">
            <h2>Admin</h2>
            <div class="col-md-6">
                <form method="post" action="/student/{{$student->id}}" class="container-fluid">
                    <div class="form-group">
                        <label for="tutor">Allocate To Tutor</label>
{{--
                        <select name="tutor" id="tutor" class="form-control">
                            <option value="">Select One</option>
                            @foreach($tutors as $tutor)
                                <option value="{{$tutor->id}}">{{$tutor->id}}: {{$tutor->first_name}} ({{$tutor->last_name}})</option>
                            @endforeach
                        </select>
--}}
                        <input type="number" placeholder="Tutor ID" name="tutor" id="tutor" class="form-control">
                    </div>
                    @if($is_admin)
                    <div class="form-group">
                        <label for="user">Allocate To Coordinator (Admin Only - Will Override Previous Field)</label>
                        <select name="user" id="user" class="form-control" onchange="$('#status').val('In-Progress');">
                            <option value="">Select One</option>
                            @foreach($users as $user)
                                <option value="{{$user->id}}">{{$user->id}}: {{$user->name}}</option>
                            @endforeach
                        </select>
                    </div>
                    @endif
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select name="status" id="status" class="form-control">
                            <option value="">Choose One</option>
                            <option value="Available">Available</option>
                            <option value="In-Progress">In-Progress</option>
                            <option value="Successful">Successful</option>
                            <option value="Unsuccessful">Unsuccessful</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <a href = "/student/{{$student->id}}/destroy" class = "btn btn-danger">Delete</a>
                        <button type="submit" class="btn btn-default">Update</button>
                    </div>
                </form>
                <div class="container-fluid">
                    @if(count($student->allocations)>0)
                        Allocation History
                        <br />
                        <table>
                            <tr>
                                <th>No.</th>
                                <th>Tutor</th>
                                <th>Coordinator</th>
                                <th>Status</th>
                                <th>Last Modified</th>
                            </tr>
                        @foreach($student->allocations as $index => $allocation)
                            <tr>
                                <th>{{$index + 1}}</th>
                                <th>{{(isset($allocation->tutor))? $allocation->tutor->id.":".$allocation->tutor->first_name." ".$allocation->tutor->last_name : ""}}</th>
                                <th>{{$allocation->user->id}} : {{$allocation->user->name}}</th>
                                <th>{{$allocation->status}}</th>
                                <th>{{$allocation->updated_at->format("d M Y H:i")}}</th>
                            </tr>
                        @endforeach
                        </table>
                    @endif
                </div>
            </div>
            <div class="col-md-6">
                <ul>
                @foreach($student->comments as $comment)
                    <li class="container-fluid"><pre class="col-md-8">{{$comment->comment}}</pre>
                    <span class="subText col-md-4">{{$comment->user->name}}</span>
                    </li>
                @endforeach
                </ul>
                <form method="post" action="/student/{{$student->id}}/comment">
                    <div class="form-group">
                        <label for="comment-box">Comment:</label>
                        <textarea name="comment" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-default">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
