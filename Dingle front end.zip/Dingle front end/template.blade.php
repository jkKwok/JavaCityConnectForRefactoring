<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>DingleX</title>

    <!-- Bootstrap Core CSS -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="/css/assignment.css" rel="stylesheet">
    <link href="/css/agency.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>
    <link rel="icon" 
      type="image/png" 
      href="img/favicon.ico">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->


    <!-- jQuery -->
    <script src="/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="/js/jquery.easing.min.js"></script>
    <script src="/js/classie.js"></script>
    <script src="/js/cbpAnimatedHeader.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="/js/jqBootstrapValidation.js"></script>
<!--     <script src="js/contact_me.js"></script> -->

    <!-- Custom Theme JavaScript -->
    <script src="/js/agency.js"></script>



</head>

<body id="page-top" class="index">
    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="index.php" font="">Dingle Tuition Agency</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="index.php">Service Details</a>
                    </li>
           
                    <li>
                        <a class="page-scroll" href="index.php">About</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="index.php">Contact</a>
                    </li>
                    <li>
                        <a class="signup" href="signup">Sign up as a Tutor</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

    <header>
        @if(isset($success))
            <script>
                alert("Your request has been submitted! We'll be in contact shortly.");
            </script>
        @endif
        <div class="container">
            <div class="intro-text" >
                <div class="intro-lead-in">Finding a tutor is easy at Dingle!</div>
                <div class="intro-heading">Scroll Down for More</div>
            </div>
        </div>
    </header>
	<div class="content">
      <h3><strong>Getting started</strong></h3>
        <p>&nbsp;</p>
        <p>Dear parents and students, kindly fill in the request form on the left to request for a tutor. One of our friendly staff will attend to you within 12 hours.</p>
        <p><strong>You get to enjoy the following:</strong></p>
        <p>1. Free matching service<br> 2. No hidden charges<br> 3. Commission is levied from tutor</p>
        <p><strong>Request a tutor via phone</strong></p>
        <p>We accept phone request too. Call us at <span style="color: #f2664f;"><strong>97881548 (SMS)</strong></span>. We will be more than happy to help you.</p>
	</div>
	<div id="home-tutor-table" class="content">
        <form name="frmTutor" method="post" action="/request">
            <h3>Student (Tutee) Particulars</h3>
            
            	<p>
            For <b>group tuition</b> (more than 1 student), fill in details of one of them below and indicate the number of students and other details in the "5. Remarks, Notes &amp; Other Requirements" section.
            	</p>
            	<table>
            	<tbody><tr>
            <th>Name</th>
            <td><input type="text" name="name" maxlength="20" size="20"></td>
            	</tr>
            	<tr>
            <th>Year of Birth</th>
            <td>
            
            <!-- ~~~~~ ~~~~~ | Year | ~~~~~ ~~~~~ -->
            <select name="birthYear">
            <option value="">- Select One -</option>
            <option value="2011">2011</option>
            <option value="2010">2010</option>
            <option value="2009">2009</option>
            <option value="2008">2008</option>
            <option value="2007">2007</option>
            <option value="2006">2006</option>
            <option value="2005">2005</option>
            <option value="2004">2004</option>
            <option value="2003">2003</option>
            <option value="2002">2002</option>
            <option value="2001">2001</option>
            <option value="2000">2000</option>
            <option value="1999">1999</option>
            <option value="1998">1998</option>
            <option value="1997">1997</option>
            <option value="1996">1996</option>
            <option value="1995">1995</option>
            <option value="1994">1994</option>
            <option value="1993">1993</option>
            <option value="1992">1992</option>
            <option value="1991">1991</option>
            <option value="1990">1990</option>
            <option value="1989">1989</option>
            <option value="1988">1988</option>
            <option value="1987">1987</option>
            <option value="1986">1986</option>
            <option value="1985">1985</option>
            <option value="1984">1984</option>
            <option value="1983">1983</option>
            <option value="1982">1982</option>
            <option value="1981">1981</option>
            <option value="1980">1980</option>
            <option value="1979">1979</option>
            <option value="1978">1978</option>
            <option value="1977">1977</option>
            <option value="1976">1976</option>
            <option value="1975">1975</option>
            <option value="1974">1974</option>
            <option value="1973">1973</option>
            <option value="1972">1972</option>
            <option value="1971">1971</option>
            <option value="1970">1970</option>
            <option value="1969">1969</option>
            <option value="1968">1968</option>
            <option value="1967">1967</option>
            <option value="1966">1966</option>
            <option value="1965">1965</option>
            <option value="1964">1964</option>
            <option value="1963">1963</option>
            <option value="1962">1962</option>
            <option value="1961">1961</option>
            <option value="1960">1960</option>
            <option value="1959">1959</option>
            <option value="1958">1958</option>
            <option value="1957">1957</option>
            <option value="1956">1956</option>
            <option value="1955">1955</option>
            <option value="1954">1954</option>
            <option value="1953">1953</option>
            <option value="1952">1952</option>
            <option value="1951">1951</option>
            <option value="1950">1950</option>
            <option value="1949">1949</option>
            <option value="1948">1948</option>
            <option value="1947">1947</option>
            <option value="1946">1946</option>
            <option value="1945">1945</option>
            <option value="1944">1944</option>
            <option value="1943">1943</option>
            <option value="1942">1942</option>
            <option value="1941">1941</option>
            <option value="1940">1940</option>
            <option value="1939">1939</option>
            <option value="1938">1938</option>
            <option value="1937">1937</option>
            <option value="1936">1936</option>
            <option value="1935">1935</option>
            <option value="1934">1934</option>
            <option value="1933">1933</option>
            <option value="1932">1932</option>
            <option value="1931">1931</option>
            <option value="1930">1930</option>
            <option value="1929">1929</option>
            <option value="1928">1928</option>
            <option value="1927">1927</option>
            <option value="1926">1926</option>
            <option value="1925">1925</option>
            <option value="1924">1924</option>
            <option value="1923">1923</option>
            <option value="1922">1922</option>
            <option value="1921">1921</option>
            <option value="1920">1920</option>
            </select>
            
            
            </td>
            	</tr>
            	<tr>
            <th>Gender</th>
            <td>
            	<select name="gender">
            <option value="">- Select One -</option>
            <option value="m">Male</option>
            <option value="f">Female</option>
            	</select>
            </td>
            	</tr>
            	<tr>
            <th>Nationality</th>
            <td>
            	<select name="nationality" onchange="javascript:checkOthers(this,'nationality2');" onkeyup="javascript:checkOthers(this,'nationality2');">
            <option value="">- Select One -</option>
            <option value="SG">Singaporean</option>
            <option value="MY">Malaysian</option>
            <option value="EU">Eurasian</option>
            <option value="others">Others</option>
            	</select>
            	<span id="nationality_others" style="visibility:hidden;">
            <input type="text" name="nationality_others" maxlength="20" size="20">
            <i>(Please specify)</i>
            	</span>
            </td>
            	</tr>
            	<tr>
            <th>Race</th>
            <td>
            	<select name="race" onchange="javascript:checkOthers(this,'race2');" onkeyup="javascript:checkOthers(this,'race2');">
            <option value="">- Select One -</option>
            <option value="chinese">Chinese</option>
            <option value="malay">Malay</option>
            <option value="indian">Indian</option>
            <option value="eurasian">Eurasian</option>
            <option value="others">Others</option>
            	</select>
            	<span id="race_others" style="visibility:hidden;">
            <input type="text" name="race_others" maxlength="20" size="20">
            <i>(Please specify)</i>
            	</span>
            </td>
            	</tr>
            	<tr>
            <th>Tutoring Location</th>
            <td><input type="text" name="address" maxlength="50" size="40"> <i>(Address)</i></td>
            	</tr>
            	<tr>
            <th>Postal Code</th>
            <td>S<input type="text" name="postalCode" maxlength="6" size="6"></td>
            	</tr>
            	</tbody></table>
            
            <br>
            
            
            <!-- ----- ----- ----- ----- -----
            	2. Contacting Details
              ----- ----- ----- ----- ----- -->
            <h3>Contacting Details</h3>
            	<table>
            	<tbody><tr>
            <th>Contact Person</th>
            <td><input type="text" name="contactPerson" maxlength="20" size="20"> <i>(name)</i></td>
            	</tr>
            	<tr>
            <th>Relationship with Student</th>
            <td>
            	<select name="relationship">
            <option value="">- Select One -</option>
            <option value="p">Parent</option>
            <option value="g">Guardian</option>
            <option value="s">Self</option>
            	</select>
            </td>
            	</tr>
            	<tr>
            <th>Mobile Phone</th>
            <td>(+65) <input type="text" name="mobileNo" maxlength="8" size="9"></td>
            	</tr>
            	<tr>
            <th>Home Phone <i>(optional)</i></th>
            <td>(+65) <input type="text" name="homeNo" maxlength="8" size="9"> <i>(in case of emergency)</i></td>
            	</tr>
            	<tr>
            <th>Email</th>
            <td><input type="text" name="email" maxlength="60" size="30"></td>
            	</tr>
            	<tr>
            <th>Referral</th>
            <td>
            <select name="referral" onchange="javascript:checkOthers(this,'referral2');" onkeyup="javascript:checkOthers(this,'referral2');">
            <option value="N.A">N.A</option>
            <option value="email">Email</option>
            <option value="facebook">Facebook</option>
            <option value="flyer">Flyer</option>
            <option value="magazine">Magazine</option>
            <option value="newspaper">Newspaper</option>
            <option value="search engine">Search Engine</option>
            <option value="twitter">Twitter</option>
            <option value="others">Others</option>
            </select>
            	<span id="referral_others" style="visibility:hidden;">
            <input type="text" name="referral_others" maxlength="50" size="30">
            <i>(Please specify)</i>
            	</span>
            <br>
            <i>How did you find out about us?</i>
            </td>
            	</tr>
            	</tbody></table>
            
            <br>
            
            
            <!-- ----- ----- ----- ----- -----
            	3. Student's Status
              ----- ----- ----- ----- ----- -->
            <h3>Student's Status</h3>
            	<table>
            	<tbody><tr>
            <th>Current School</th>
            <td><input type="text" name="currentSchool" maxlength="40" size="30"></td>
            	</tr>
            	<tr>
            <th>Tutoring Level</th>
            <td>
            <select name="level1" id="level" onchange="javascript:checkOthers(this,'level2');" onkeyup="javascript:checkOthers(this,'level2');">
            <option value="">- Select One -</option>
            <option value="Pre-School">Pre-School</option>
            <option value="Primary 1">Primary 1</option>
            <option value="Primary 2">Primary 2</option>
            <option value="Primary 3">Primary 3</option>
            <option value="Primary 4">Primary 4</option>
            <option value="Primary 5">Primary 5</option>
            <option value="Primary 6">Primary 6</option>
            <option value="Sec 1E">Sec 1 Express</option>
            <option value="Sec 1N">Sec 1 NT / NA</option>
            <option value="Sec 2E">Sec 2 Express</option>
            <option value="Sec 2N">Sec 2 NT / NA</option>
            <option value="Sec 3E">Sec 3 Express</option>
            <option value="Sec 3N">Sec 3 NT / NA</option>
            <option value="Sec 4E">Sec 4 Express</option>
            <option value="Sec 4N">Sec 4 NT / NA</option>
            <option value="Sec 5N">Sec 5 NA</option>
            <option value="IP 1">IP Year 1</option>
            <option value="IP 2">IP Year 2</option>
            <option value="IP 3">IP Year 3</option>
            <option value="IP 4">IP Year 4</option>
            <option value="IP 5">IP Year 5 (Senior 1)</option>
            <option value="IP 6">IP Year 6 (Senior 2)</option>
            <option value="JC 1">JC 1</option>
            <option value="JC 2">JC 2</option>
            <option value="Poly">Polytechnic</option>
            <option value="BAC">Uni (Bachelor)</option>
            <option value="MAS">Uni (Master)</option>
            <option value="PhD">Uni (PhD)</option>
            <option value="Music">Music / Instrument</option>
            <option value="Language">Foreign Language</option>
            <option value="others">Others</option>
            </select>
            	<span id="level2" style="visibility:hidden;">
            <input type="text" name="level2" maxlength="20" size="20">
            <i>(Please specify)</i>
            	</span>
            </td>
            	</tr>
            	<tr>
            <th>Subject(s) for Tutoring</th>
            <td><input type="text" name="subjects" size="40" maxlength="60"></td>
            	</tr>
            	</tbody></table>
            
            <br>
            
            
            <!-- ----- ----- ----- ----- -----
            	4. Preferences
              ----- ----- ----- ----- ----- -->
            <h3>Preferences</h3>
            
            	
            
            	<table>
            	<tbody><tr>
            <th>Tutor's Gender</th>
            <td>
            <select name="tutorGender">
            <option value="n">No Preference</option>
            <option value="m">Male</option>
            <option value="f">Female</option>
            </select>
            </td>
            	</tr>
            	<tr>
            <th>Minimal Qualification</th>
            <td>
            	<select name="qualification">
            <option value="n/a">No Preference</option>
            <option value="o">'O' Level</option>
            <option value="a">'A' Level</option>
            <option value="dip">Diploma</option>
            <option value="und">Undergrad</option>
            <option value="bac">Bachelor</option>
            <option value="mas">Master</option>
            <option value="phd">PhD</option>
            	</select>
            </td>
            	</tr>
            	<tr>
            <th>Budget (Tuition Fees)</th>
            <td>$<input type="text" name="budget" maxlength="5" size="5"> per hour <i>(in Singapore dollars)</i></td>
            	</tr>
            	<tr>
            <th>Number of lesson</th>
            <td>
            	<select name="noOfLesson">
            <option value="">- Select One -</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            	</select>
            per week
            </td>
            	</tr>
            	<tr>
            <th>Duration</th>
            <td>
            	<select name="timePerLesson">
            <option value="">- Select One -</option>
            <option value="1">1 hr</option>
            <option value="1.5">1.5 hr (recommended)</option>
            <option value="2">2 hr</option>
            <option value="2.5">2.5 hr</option>
            <option value="3">3 hr</option>
            <option value="TBR">To be recommended</option>
            	</select>
            per lesson
            </td>
            	</tr>
            	<tr>
            
            <th>Timeslots</th>
            <td>
            
            	<fieldset style="background:#fcfcfc;">
            
            	<table width="100%">
            <tbody><tr>
            	<td><a href="javascript:checkAllSlots('Monday');">MON:</a></td>
            	<td><input type="checkbox" id="Monday_morning" name="time[]" value="0"><label for="Monday_morning">Morning</label></td>
            	<td><input type="checkbox" id="Monday_afternoon" name="time[]" value="1"><label for="Monday_afternoon">Afternoon</label></td>
            	<td><input type="checkbox" id="Monday_evening" name="time[]" value="2"><label for="Monday_evening">Evening</label></td>
            	</tr><tr>
            	<td><a href="javascript:checkAllSlots('Tuesday');">TUE:</a></td>
            	<td><input type="checkbox" id="Tuesday_morning" name="time[]" value="3"><label for="Tuesday_morning">Morning</label></td>
            	<td><input type="checkbox" id="Tuesday_afternoon" name="time[]" value="4"><label for="Tuesday_afternoon">Afternoon</label></td>
            	<td><input type="checkbox" id="Tuesday_evening" name="time[]" value="5"><label for="Tuesday_evening">Evening</label></td>
            	</tr><tr>
            	<td><a href="javascript:checkAllSlots('Wednesday');">WED:</a></td>
            	<td><input type="checkbox" id="Wednesday_morning" name="time[]" value="6"><label for="Wednesday_morning">Morning</label></td>
            	<td><input type="checkbox" id="Wednesday_afternoon" name="time[]" value="7"><label for="Wednesday_afternoon">Afternoon</label></td>
            	<td><input type="checkbox" id="Wednesday_evening" name="time[]" value="8"><label for="Wednesday_evening">Evening</label></td>
            	</tr><tr>
            	<td><a href="javascript:checkAllSlots('Thursday');">THU:</a></td>
            	<td><input type="checkbox" id="Thursday_morning" name="time[]" value="9"><label for="Thursday_morning">Morning</label></td>
            	<td><input type="checkbox" id="Thursday_afternoon" name="time[]" value="10"><label for="Thursday_afternoon">Afternoon</label></td>
            	<td><input type="checkbox" id="Thursday_evening" name="time[]" value="11"><label for="Thursday_evening">Evening</label></td>
            	</tr><tr>
            	<td><a href="javascript:checkAllSlots('Friday');">FRI:</a></td>
            	<td><input type="checkbox" id="Friday_morning" name="time[]" value="12"><label for="Friday_morning">Morning</label></td>
            	<td><input type="checkbox" id="Friday_afternoon" name="time[]" value="13"><label for="Friday_afternoon">Afternoon</label></td>
            	<td><input type="checkbox" id="Friday_evening" name="time[]" value="14"><label for="Friday_evening">Evening</label></td>
            	</tr><tr>
            	<td><a href="javascript:checkAllSlots('Saturday');">SAT:</a></td>
            	<td><input type="checkbox" id="Saturday_morning" name="time[]" value="15"><label for="Saturday_morning">Morning</label></td>
            	<td><input type="checkbox" id="Saturday_afternoon" name="time[]" value="16"><label for="Saturday_afternoon">Afternoon</label></td>
            	<td><input type="checkbox" id="Saturday_evening" name="time[]" value="17"><label for="Saturday_evening">Evening</label></td>
            	</tr><tr>
            	<td><a href="javascript:checkAllSlots('Sunday');">SUN:</a></td>
            	<td><input type="checkbox" id="Sunday_morning" name="time[]" value="18"><label for="Sunday_morning">Morning</label></td>
            	<td><input type="checkbox" id="Sunday_afternoon" name="time[]" value="19"><label for="Sunday_afternoon">Afternoon</label></td>
            	<td><input type="checkbox" id="Sunday_evening" name="time[]" value="20"><label for="Sunday_evening">Evening</label></td>
            	</tr>	</tbody></table>
            	</fieldset>
            
            <br><i>(Your chance of matching with a home tutor will be higher if you have more available timeslots)</i>
            </td>
            	</tr>
            	</tbody></table>
            
            <br>
            
            
            <!-- ----- ----- ----- ----- -----
            	5. Remarks / Notes for Smart Tuition
              ----- ----- ----- ----- ----- -->
            <h3>Remarks, Notes &amp; Other Requirements</h3>
            
            	<p>
            To help us to assist you better, do indicate if you have any <b>special requirement or information</b>, such as the student's <b>latest exam results</b>. The more details you give us, the better we can do the matching for you.
            <br>
            <textarea cols="60" rows="10" name="remarks"></textarea>
            	</p>
            
            <br>
            
            {{ csrf_field() }}
            <input type="submit" value="Submit Request" title="Submit request for tutor"  style="padding:10px; cursor:pointer;">
            	</center>
        </form>
    </div>
</body>

</html>
