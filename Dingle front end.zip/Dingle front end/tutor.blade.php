@extends("templates.dashboard")

@section("content")
    <div id="tutorDetails">
        <h1>{{$tutor->id}}: {{$tutor->first_name}} ({{$tutor->last_name}})</h1>
        <div class="container-fluid">
            <table>
                <tr>
                    <th>NRIC</th>
                    <td>{{$tutor->nric}}</td>
                    <th>Status</th>
                    <td>{{$tutor->approval}}</td>
                </tr>
                <tr>
                    <th>Age</th>
                        <td>{{$tutor->age()}}
                            <span class="subtext">({{$tutor->birthday()}})</span>
                            </td>
                    <th>Availability</th>
                    <td>Available</td>
                </tr>
                <tr>
                    <th>Gender</th>
                    <td>{{$tutor->gender}}</td>
                    <th>Qualification</th>
                    <td>{{$tutor->highest_qualification}}</td>
                </tr>
                <tr>
                    <th>Nationality</th>
                    <td>{{$tutor->nationality}}</td>
                    <th>Race</th>
                    <td>{{$tutor->race}}</td>
                </tr>
                <tr>
                    <th>Occupation</th>
                    <td>{{$tutor->occupation}}</td>
                    <th>Experience</th>
                    <td>{{$tutor->experience}} years</td>
                </tr>
            </table>
        </div>
        <div class="container-fluid">
            <h2>Contact Details</h2>
            <table>
                <tr>
                    <th>Email</th>
                    <td><a href="mailto:{{$tutor->email}}">{{$tutor->email}}</a></td>
                </tr>
                <tr>
                    <th>Mobile Phone</th>
                    <td>{{$tutor->mobile_phone}}</td>
                </tr>
                <tr>
                    <th>Home Phone</th>
                    <td>{{$tutor->home_phone}}</td>
                </tr>
                <tr>
                    <th>Address</th>
                    <td>{{$tutor->address}}</td>
                </tr>
                <tr>
                    <th>Postal Code</th>
                    <td>{{$tutor->postal_code}}</td>
                </tr>
            </table>
        </div>
        <div class="container-fluid">
            <h2>Education History</h2>
            <table>
                <tr>
                    <th>NIE Trained</th>
                    <td>{{($tutor->nie_graduated)? "Yes": "No"}}</td>
                </tr>
                <tr>
                    <th>Special Programme</th>
                    <td>{{$tutor->attended_ip_ib}}</td>
                </tr>
                <tr>
                    <th>Secondary School</th>
                    <td>{{$tutor->secondary_school}}</td>
                </tr>
                <tr>
                    <th>JC/Poly</th>
                    <td>{{$tutor->jc_poly}} ({{$tutor->jc_poly_course}})</td>
                </tr>
                <tr>
                    <th>University</th>
                    <td>{{$tutor->university}} ({{$tutor->university_course}})</td>
                </tr>
                <tr>
                    <th>Results</th>
                    <td><pre>{{$tutor->results}}</pre></td>
                </tr>
            </table>
        </div>
        <div class="container-fluid">
            <h2>Preferences</h2>
            <table>
                <tr>
                    <th>Teach IP</th>
                    <td>{{($tutor->teach_ip)? "Yes" : "No"}}</td>
                </tr>
                <tr>
                    <th>Minimal Expected Rate</th>
                    <td>{{$tutor->minimal_amount}}</td>
                </tr>
                <tr>
                    <th>Student's Gender</th>
                    <td>{{$tutor->gender_preference}}</td>
                </tr>
                <tr>
                    <th>Locations</th>
                    <td>{{implode(", ", $tutor->locations())}}</td>
                </tr>
            </table>
        </div>
        <div class="container-fluid">
            <h2>Tutoring Subjects</h2>
            <ul>
                @foreach($tutor->subjects as $subject)
                    <li>{{$subject->subject_name}}</li>
                @endforeach
            </ul>
        </div>
        <div class="container-fluid">
            <h2>Self-Introduction</h2>
            <pre>{{$tutor->self_intro}}</pre>
        </div>
        <div class="container-fluid">
            <h2>Comments for Coordinators</h2>
            <pre>{{$tutor->remarks}}</pre>
        </div>
        <div class="container-fluid">
            <h2>Admin</h2>
            <div class = "col-md-6">
                <form method="post" action="/tutor/{{$tutor->id}}">
                    <div class="form-group">
                        <label for="comment-box">Approval Status</label>
                        <select name="approval" class="form-control">
                            <option value="">Pending</option>
                            <option value="Approved">Approved</option>
                            <option value="Rejected">Rejected</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <a href = "/tutor/{{$tutor->id}}/destroy" class = "btn btn-danger">Delete</a>
                        <button type="submit" class="btn btn-default">Update</button>
                    </div>
                </form>
            </div>
            <div class = "col-md-6">
                <ul>
                @foreach($tutor->comments as $comment)
                    <li class="container-fluid"><pre class="col-md-8">{{$comment->comment}}</pre>
                    <span class="subText col-md-4">{{$comment->user->name}}</span>
                    </li>
                @endforeach
                </ul>
                <form method="post" action="/tutor/{{$tutor->id}}/comment">
                    <div class="form-group">
                        <label for="comment-box">Comment:</label>
                        <textarea name="comment" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-default">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection