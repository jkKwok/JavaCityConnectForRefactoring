@extends("templates.dashboard")

@section("content")
<div class="container-fluid">
    <h1>Manage Users</h1>
    <div class="col-md-6">
        <h2>Current Users</h2>
        <table class="col-md-12">
            <tr>
                <th>User ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Is Admin</th>
            </tr>
            @foreach($users as $user)
                <tr>
                    <td>{{$user->id}}</td>
                    <td>{{$user->name}}</td>
                    <td>{{$user->email}}</td>
                    <td>
                        @if($user->id == Auth::user()->id)
                            Yes
                        @elseif($user->is_admin)
                            Yes<!--  <a href="/changeadmin/{{$user->id}}" class="btn btn-default">Remove Admin</a> -->
                        @else
                            No <!--  <a href="/changeadmin/{{$user->id}}" class="btn btn-default">Make Admin</a> -->
                        @endif
                    </td>
                    <td><a href="/user/{{$user->id}}/password" class="btn btn-default">Change Password</a></td>
                        @if($user->id != Auth::user()->id)
                            <td><a href="/user/{{$user->id}}/delete" class="btn btn-danger">Delete User</a></td>
                        @endif
                </tr>
            @endforeach
        </table>
    </div>
    <form action="/user" method="post" class="col-md-6">
        <h2>New User</h2>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" class="form-control">
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" class="form-control">
        </div>
        <div class="form-group">
            <label for="password">Pasword</label>
            <input type="text" id="password" name="password" class="form-control">
        </div>
        <label>
            <input type="checkbox" name="is_admin" value="true" /> Is Admin? (Unselect for coordinators)
        </label>
        <div class="form-group">
            <button type="submit" class="btn btn-default">Create User</button>
        </div>
    </form>
</div>
@endsection