@extends("templates.basic")

@section("title")
Welcome to DingleX
@endsection

@section("extras")
<script>
$(() => $(".others").change(function(e){
  if($(this).val() == "others"){
   $($(this).attr("data-target")).collapse("show");
  } else{
   $($(this).attr("data-target")).collapse("hide");
  }
}));
</script>
@endsection

@section("content")
<style>
#jumbotron {
  background: no-repeat center url(/img/jumbotron.jpg), #000;
}

.card {
  border-radius: 10px;
  border: 1px solid #ccc;
  width: auto;
  height: 12em;
  padding: 0.5em 2em;
  margin: 0.5em;
}
.card .price {
  font-size: 2em;
  font-weight: bold;
}
.card .price::before {
  content: '$';
  font-size: 0.6em;
  vertical-align: top;
  color: #aaa;
}
.card h2 {
  font-size: 1.5em;
}

#quote-carousel *, #feature-carousel * {
  color: #000;
}

#quote-carousel .carousel-control, #feature-carousel .carousel-control {
  background-image: none;
  font-size: 0.5em;
}

#quote-carousel .carousel-control.left,
#feature-carousel .carousel-control.left {
  left: -50px;
}

#quote-carousel .carousel-control.right,
#feature-carousel .carousel-control.right {
  right: -50px;
}

#quote-carousel .carousel-indicators,
#feature-carousel .carousel-indicators {
  color: #000;
  bottom: -50px;
}

#quote-carousel .carousel-indicators li,
#feature-carousel .carousel-indicators li {
  border: 1px solid #000;
}

#quote-carousel .carousel-indicators li.active,
#feature-carousel .carousel-indicators li.active {
  background-color: #000;
}

#quote-carousel .carousel-caption,
#feature-carousel .carousel-caption {
  top: 25%;
  height: 50%;
}
.carousel-inner img {
  margin: 0 auto;
}
#quote-carousel img {
  height: 40em;
}
@media (max-width: 767px) {
  #feature-carousel-container {
    display: none;
  }
}

footer {
  padding: 2em 0 4em 0;
  text-align: center;
  background: #000;
  color: #fff;
}
</style>
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-12 text-center">
      <img src="/img/xlogo.png" style="width:100px">
    </div>
  </div>
  <div class="row">&nbsp;</div>
  <div class="row">
    <div class="col-sm-12">
      <div class="jumbotron text-center"
        id="jumbotron">
        <h1 style="font-size:4em">
          we are 20,000 tutors strong
        </h1>
        <h2 style="font-size:2em">
          engage us now as your 1-to-1 home tuition specialist
        </h2>
      </div>
    </div>
  </div>
  <div class="row separator"></div>
  <div class="row">
    <a id="about-section"></a>
    <div class="col-sm-12">
      <div class="col-sm-5">
        <div class="row">
          <div class="col-sm-6">
            <div class="card">
              <h2>Primary 1-3</h2>
              <span class="price">27-31</span>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="card">
              <h2>Secondary 1-2</h2>
              <span class="price">38-41</span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-6">
            <div class="card">
              <h2>Primary 4-6</h2>
              <span class="price">30-32</span>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="card">
              <h2>Secondary 3-4</h2>
              <span class="price">39-42</span>
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-7 form-region" style="background:#f4f4f4;padding:2em">
        <form class="form-horizontal" method="post" action="/request">
          <h2>Have questions? We would like to help</h2>
          <div class="form-group">
            <input name="contact_name" type="text" placeholder="Your Name"
            class="form-control">
          </div>
          <div class="form-group">
            <input name="name" type="text" placeholder="Student Name"
            class="form-control">
          </div>
          <div class="form-group">
            <input name="mobile_phone" type="tel" placeholder="Mobile"
            class="form-control">
          </div>
          <div class="form-group">
            <input name="email" type="email" placeholder="Home Address"
            class="form-control">
          </div>
          <div class="form-group form-inline">
            <select class="form-control others" data-target="#level_others"
              id="level" name="level">
              <option value>
                  - Select Level -
              </option>
              <option value="Pre-School">
                  Pre-School
              </option>
              <option value="Primary 1">
                  Primary 1
              </option>
              <option value="Primary 2">
                  Primary 2
              </option>
              <option value="Primary 3">
                  Primary 3
              </option>
              <option value="Primary 4">
                  Primary 4
              </option>
              <option value="Primary 5">
                  Primary 5
              </option>
              <option value="Primary 6">
                  Primary 6
              </option>
              <option value="Sec 1E">
                  Sec 1 Express
              </option>
              <option value="Sec 1N">
                  Sec 1 NT / NA
              </option>
              <option value="Sec 2E">
                  Sec 2 Express
              </option>
              <option value="Sec 2N">
                  Sec 2 NT / NA
              </option>
              <option value="Sec 3E">
                  Sec 3 Express
              </option>
              <option value="Sec 3N">
                  Sec 3 NT / NA
              </option>
              <option value="Sec 4E">
                  Sec 4 Express
              </option>
              <option value="Sec 4N">
                  Sec 4 NT / NA
              </option>
              <option value="Sec 5N">
                  Sec 5 NA
              </option>
              <option value="IP 1">
                  IP Year 1
              </option>
              <option value="IP 2">
                  IP Year 2
              </option>
              <option value="IP 3">
                  IP Year 3
              </option>
              <option value="IP 4">
                  IP Year 4
              </option>
              <option value="IP 5">
                  IP Year 5 (Senior 1)
              </option>
              <option value="IP 6">
                  IP Year 6 (Senior 2)
              </option>
              <option value="JC 1">
                  JC 1
              </option>
              <option value="JC 2">
                  JC 2
              </option>
              <option value="Poly">
                  Polytechnic
              </option>
              <option value="BAC">
                  Uni (Bachelor)
              </option>
              <option value="MAS">
                  Uni (Master)
              </option>
              <option value="PhD">
                  Uni (PhD)
              </option>
              <option value="Music">
                  Music / Instrument
              </option>
              <option value="Language">
                  Foreign Language
              </option>
              <option value="others">
                  Others
              </option>
            </select>
            <input name="subjects" type="text"
              placeholder="Tuition Subject"
              class="form-control">
          </div>
          <div class="form-group">
            <span class="collapse fade" id="level_others">
              <input class="form-control" maxlength="20" name="level_others"
                placeholder="Level" size="20" type="text">
              <i>(Please specify)</i>
            </span>
          </div>
          <div class="form-group">
            <input type="submit" value="Submit" class="btn btn-default">
          </div>
        </form>
      </div>
    </div>
  </div>
  <div class="row separator"></div>
  <div class="row" style="margin:8em 4em" id="feature-carousel-container">
    <div class="col-sm-12">
      <div class="carousel slide" data-ride="carousel" id="feature-carousel">
        <ol class="carousel-indicators">
          <li data-target="#feature-carousel" data-slide-to="0" class="active"></li>
          <li data-target="#feature-carousel" data-slide-to="1"></li>
          <li data-target="#feature-carousel" data-slide-to="2"></li>
          <li data-target="#feature-carousel" data-slide-to="3"></li>
          <li data-target="#feature-carousel" data-slide-to="4"></li>
          <li data-target="#feature-carousel" data-slide-to="5"></li>
        </ol>
        <div class="carousel-inner" role="listbox">
          <div class="item active">
            <img src="img/Feature1.jpg">
          </div>
          <div class="item">
            <img src="img/Feature2.jpg">
          </div>
          <div class="item">
            <img src="img/Feature3.jpg">
          </div>
          <div class="item">
            <img src="img/Feature4.jpg">
          </div>
          <div class="item">
            <img src="img/Feature6.jpg">
          </div>
          <div class="item">
            <img src="img/Feature7.jpg">
          </div>
        </div>
        <a href="#feature-carousel" class="left carousel-control" data-slide="prev" role="button">
          <span class="glyphicon glyphicon-chevron-left"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a href="#feature-carousel" class="right carousel-control" data-slide="next" role="button">
          <span class="glyphicon glyphicon-chevron-right"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
    </div>
  </div>
  <div class="row" style="margin:8em 4em">
    <h3 class="col-sm-4" style="margin-top:0">
      WHO WE ARE
    </h3>
    <div class="col-sm-8">
      <p>
DingleX is a dedicated 1-to-1 home tuition agency that provides 1-to-1 home tutors for primary, secondary, junior college and
university students in Singapore. We connect students with 1-to-1 home tutors to help them solve their academic problems according
to each student's academic situation and our client's budget.
      </p>
      <p>
We take pride in our service and make our client's needs a priority.
      </p>
      <p>
Engage us to find a 1-to-1 home tutor now!
      </p>
    </div>
  </div>
  <hr>
  <div class="row text-center" style="margin:8em 4em">
    <div class="col-sm-4">
      <h3>Reliable</h3>
      <p>
<b>Detailed assessment of your child's academic situation</b> before finding
the right 1-to-1 tutor (Free).<br>
      </p>
      <p>
<b>Highly qualified and strictly trained coordinators</b> to find the perfect
1-to-1 tutor for your child.<br>
      </p>
      <p>
Extensive lifetime follow-up support
      </p>
    </div>
    <div class="col-sm-4">
      <h3>Effective</h3>
      <p>
<b>20,000 professional and experienced 1-to-1 tutors</b> with verified
credentials and proven track record to help your child excel.
      </p>
      <p>
Available for all levels and subjects
      </p>
    </div>
    <div class="col-sm-4">
      <h3>Efficient</h3>
      <p>
<b>Comprehensive coordinating system</b> with state-of-the-art technology.
      </p>
      <p>
Extensive.<br>
Detailed.
      </p>
      <p>
Precise.<br>
Ultra-fast.
      </p>
    </div>
  </div>
  <hr>
  <div class="row">
    <div class="col-sm-12">
      <div class="carousel slide" data-ride="carousel" id="quote-carousel">
        <ol class="carousel-indicators">
        </ol>
        <div class="carousel-inner" role="listbox">
          <div class="item active">
            <img src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='500' height='200'></svg>">
            <div class="carousel-caption">
              <p>
"Bing Lian is a committed and helpful tutor and I am pleased
with the matching service. I would like to use this agency again to look for another tutor."
              </p>
              <p>
Mrs Mak @ Clementi Street
              </p>
            </div>
          </div>
          <div class="item">
            <img src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='500' height='200'></svg>">
            <div class="carousel-caption">
              <p>
"My son scored an A in Math thanks to his tutor Boyu, I am very pleased with the tutor matching services provided by DingleX.
The tutor that was recommended to us puts in a lot of effort into teaching my son.
He is no longer at risk of failing his Chinese."
              </p>
              <p>
Mrs Tan @ Choa Chu Kang
              </p>
            </div>
          </div>
          <div class="item">
            <img src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='500' height='200'></svg>">
            <div class="carousel-caption">
              <p>
"The tutor is very dedicated and motivating. So far there are no problems at all.
 My daughter likes her a lot and they get along well.
The tutor meets my requirements and I would say that DingleX has made a good match for my daughter.
I would definitely recommend the services of DingleX to other parents."
              </p>
              <p>
Mrs Lee @ Yew Tee
              </p>
            </div>
          </div>
          <div class="item">
            <img src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='500' height='200'></svg>">
            <div class="carousel-caption">
              <p>
"Thank you DingleX for helping me to find such a good tutor Akshay! Even though it is just the 2nd lesson,
I can feel my grades improving already!"
              </p>
              <p>
Amanda @ Yishun
              </p>
            </div>
          </div>
          <div class="item">
            <img src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='500' height='200'></svg>">
            <div class="carousel-caption">
              <p>
My daughter gets along well with Miss Sally.
She feels the tutor can help clarify her doubts and explain the text clearly.
The tutor is also well-versed in the subject and I am pleased with my daughter’s science results.
Not only did DingleX help me find me this tutor in a short period of time,
my daughter also found this tutor more effective than previous tutors
recommended by other tuition agencies.
I would definitely recommend DingleX to other parents.
              </p>
              <p>
Mr Nirmal @ Admirity Link
              </p>
            </div>
          </div>
        </div>
        <a href="#quote-carousel" class="left carousel-control" data-slide="prev" role="button">
          <span class="glyphicon glyphicon-chevron-left"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a href="#quote-carousel" class="right carousel-control" data-slide="next" role="button">
          <span class="glyphicon glyphicon-chevron-right"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
    </div>
  </div>
  <hr>
  <div class="row">
    &nbsp;
  </div>
</div>
<footer>
  Dingle X
</footer>
@endsection
