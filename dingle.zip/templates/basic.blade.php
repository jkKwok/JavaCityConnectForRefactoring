<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>
      @yield("title")
    </title>
    <!-- Bootstrap Core CSS -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <script src="/js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="/js/bootstrap.min.js"></script>
    <link href="/css/app.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="img/favicon.ico">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
      #navbar-primary {
        border-radius: 0;
        margin: 10px;
        font-weight: bold;
      }
      .separator {
        border-bottom: 10px solid #000;
        margin: 20px 10px;
      }
      #jumbotron {
        background-size: cover;
        height: 30em;
      }
      #jumbotron h1, #jumbotron h2 {
        text-transform: uppercase;
        color: white;
      }
    </style>
    @yield("extras")
  </head>
  <body>
    <nav class="navbar navbar-default" id="navbar-primary">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button"
            class="navbar-toggle collapsed"
            data-toggle="collapse"
            data-target="#dingle-navbar-collapse"
            aria-expanded="false">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand"></a>
        </div>
        <div class="collapse navbar-collapse" id="dingle-navbar-collapse">
          <ul class="nav navbar-nav navbar-right">
            <li>
              <a>
                <span class="glyphicon glyphicon-earphone" style="font-size:0.8em"></span>
                <span style="color:#bfaf89">(+65) 9788 1548</span>
              </a>
            </li>
            <li>
              <a href="/signup">
                JOIN US
              </a>
            </li>
            <li style="margin-left:20px">&nbsp;</li>
          </ul>
        </div>
      </div>
    </nav>
    @yield("content")
  </body>
</html>
