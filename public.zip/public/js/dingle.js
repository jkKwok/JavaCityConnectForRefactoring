$(document).ready(function(){
    $(".others").change(function(e){
        if($(this).val() == "others"){
           $($(this).attr("data-target")).collapse("show");
        } else{
           $($(this).attr("data-target")).collapse("hide");

        }
    });
    
});