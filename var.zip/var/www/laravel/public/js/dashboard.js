$(document).ready(function(){
    $("#collated").hide();
    $("#openCollate").click(function(){
        // TODO: change behaviour, send value to mail server
        var value = $('#collated-numbers').val();
        $.ajax({
          method: 'POST',
          url: '/search/send/collated',
          data: {
            message: value
          }
        }).done(function(_) {console.log(_);});
    })
    $("#user").change(function(){
        $("#status").val("In-Progress");
    });
    $("#tutor").change(function(){
        $("#status").val("Successful");
    });
});
