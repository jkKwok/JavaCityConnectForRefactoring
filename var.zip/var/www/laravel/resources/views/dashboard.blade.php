@extends("templates.dashboard")

@section("content")
        
    
@endsection