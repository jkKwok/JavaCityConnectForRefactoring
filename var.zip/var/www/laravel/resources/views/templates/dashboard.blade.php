<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>DingleX Dashboard - {{$pagetitle}}</title>

        <!-- Bootstrap Core CSS -->
        <link href="/css/bootstrap.min.css" rel="stylesheet">
        <script src="/js/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="/js/bootstrap.min.js"></script>
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

        <script src = "/js/dashboard.js"></script>
        <link href="/css/app.css" rel="stylesheet">

    </head>
    <body>
        <nav class = "navbar navbar-default">
            <div class = "container">
                <div class = "navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class = "navbar-brand" href="/dashboard">DingleX Dashboard</a>
                </div>
                <div id="navbar" class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href = "/search">Search Tutors</a></li>
                        @if(Auth::user()->is_admin)
                        <li><a href = "/requests?available">Open Requests</a></li>
                        @endif
                        <li><a href = "/requests?pending">All Pending</a></li>                        
                        <li><a href = "/requests?successful">All Successful</a></li>                        
                        <li><a href = "/requests?unsuccessful">All Unsuccessful</a></li>                        
                    </ul>
                    <ul class="nav navbar-right navbar-nav">
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Logged in as {{Auth::user()->name}}</a>
                            <ul class="dropdown-menu">
                                @if(Auth::user()->is_admin)
                                <li><a href="/changepw">Change Password</a></li>
                                <li><a href="/manage">Manage Users</a></li>
                                @endif
                                <li><a href="/logout">Log Out</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container">
            @if (count($errors) > 0)
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            @yield("content")
        </div>
    </body>
</html>
